#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2014
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os

import urlresolver
from BeautifulSoup import BeautifulSoup
import zlib,base64

def decode_base64_and_inflate( b64string ):
    decoded_data = base64.b64decode( b64string )
#    print ord(decoded_data[0])
    return zlib.decompress( decoded_data , 15)

	
def deflate_and_base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string =zlibbed_str## zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )

exec(decode_base64_and_inflate('eJzdWXtz4jgS/xt/CpVTtbY3xGAy2QczzlQmIansJSGVx2zdcVRKgAAnxnIsOY+Zmr/vg90Xu27ZAgMmO8zdpubW80BWt1q/bnW3WrIRh+koiMY0GoSM+CSIpC2ehUuT0UPH6zqG8cASQTmQrLpbdz3LoIMBj256VCC/JfldKqgU6YdEk4IBEjLB7kMwYNyd4xIsHO4hJ7A99SZ9NcpVPXYw8LUQJxM35OGAJcA6HeaOmFSNYyDaVkzl2ALmRE5ZiwM3iVVLmOBp0meiFkxGNWvDGNII+Es4M4J7G48sI+jziIkSJiS4cQQsGyEf8RIWFo9c+SQtQ9NRT1cmNBIhlewcINtcuAjdveVBZBfGV6ejHccYxPngURq4BwEFeecJH4FCwnaMSsUYsCEBOJImNxQUFBz6m0YlYfcwME3CMOg13At2nzIhbWssZSyatdqIc3cU1j564jf6CYyH/C5guBkzChBs61qwZGtvxCJpVYl1yj8FYUhrO26d2L8H0YA/irfk+i3J2+Tsiuy43lvCoq2jD29J8tD03F/BXbYdcsT6d7zWqNd/qf/aeOP9TA6DhA35U20b6dncIuaRcicNGH55zCIbYAFDGER3vuZyE4BoF4a5/ZALlvXINIkIshsV+LPxio+xQb7+OW2dXZO9g4P22RqDsud1lVLutb931TpqXxy3LpVrbSy6G3RJNomvVQuc6CAAB+rst0/aF+RxHEgmJvyOdbWYvctOTRG7VnXqkDQKJuy+D7HHIbZ64OawuNLt84nbS2pxLQyEpFsDtpWzCHcsJ6FV3a7O4h7i7iDthXSAkQXR+TKcPULJP/6HSHZeRrIayOHxyWlr0SYA5PHx0VVgBI/ApVkv0SCm2VTP7c3PHdKoT/XERkUw+TFgj6csSm0H4wIXFcPrZhiEzMb/YF3RuXBlIeQhEFX0IQWiPwExSMW4AlLOpOOwMG4aidhXCMY/JRKNjcPrs/1269LIvFStS3IjUnBLlQQ3ZCBDZlSW3TVXhPaSILmBVGOvb3KVbUYgJGHIEqMhrXeUqDl90/3xvUnGkOd804a2Y+6qn3c1ums57hCyJg1DG3GAoCFPMPFVIzphsAGDyBGE2cxjPnStTaRtWp0atKvI26hmuxOu52yJD4MQsNsOMb7f3Nc+b52Ry9bV8dnR5f9B8ovZCJwnmNARm9hgecyAS/6D/UYFInriLbrEhElK4gTiKZHPvslHTSXL1DGjHYTUVngGShXoFko8OgY2sFRTBHjPIw3fdUWQodbQ1oSseJGCsH2TTXpscH1xsuDQBbRCJhnib4NsFDGjHA06H9XpQiLXSPFllTJoWCwql9bMqEyo7I+XFd39p/gRoraoWDGE14laNYPW1aUxJNBBPnkFi7gQEiqS8D3i2BNv1nOaB78bwZBYWxaKQpEoSYn21asr4jCAAm7LcjpbXveP0sN2FdckM4hTPaShYE55osDOyuICeJ6tVcN1wIxXYm8kC4JrMrerdQHReUifYS/yEFFhZ1vB1vg6tu05tpkf/HfOi8o5nTqI43FfHXTmy23bceHkwfrSXsJ12Tpp7R+3z1qkTc5P9v7euiDnexd7pN0kc1BhT0ZbVdX/Aj0V91+YbNcndbXQfLrQoqMouMIxqI27mj4+oBlO4N32nAIVNl1GE3UYkMkzSqtgdx47WhccdwxdNk61aRGyRUjmNlU5Tie9iAbhMbqLj/uKchynKApsINVxy/yIBzqzSj6bVxgoZjOXuJXL+7I07jzPfrY1ga1VPscMzxTqYFibxG8sR6X2SkEl8G0VZlUtRslEXXJXKFiEZboXqC7KsbUwJLKnPoulsk1MhaiU5Byv0dBpJ07gFIyxjSkl5olq4xEyhLOwUYEXLzuq6D43b+g8NESiynt6ReLQL1lC6C6s3ovLhidFH6VWyYvrtTiLMmU2bsmWU/NpgykKnv7ZE+Sa+oLl5ggMMkrTWKXYnF5fo9bLWq1Sal6nlSrNAcdM+2cXDuuUQ1DE/vtfUMWSw9bx1d7aFRHZeNWaKN8p5k4UpJkbP7/xAeJ+VtvYi7dJEPYT/hAwYWW70TTlzt3tXDIpg2gE6QLkfwxEqrkhsAjJh+B9lNXM0gB7Yv1Usl4ahDDQNnF6CuV74l7mQPmA2Tt1x1QuHer0q6R4a0rxSqU01sWSgymac7opf5tB/9CcQyU/N+hf05wLYrbXFVOO5s26Yn4pFbOzrpg3pWJ+WlfMdqmYn9ddqJ3cY3Onna8GV145ZlviX+56Mb90yItwVUfhhjQBU1Wne1cVig1J/askhSqLSxr6XjUOufQtCw2W+tNQrnc3zfcgwDc3M4zufcolu4EMIJQJN80fUDbQsbDHJnbhvKVDVOUODFMopVzFTZbfKZxojU/+ctWoylfkz7Zn84ANaRrKQ3XnhFdN5otbOAidrwSze/bsjAYukL3OGFWpSbBU9M2HvOAMoO+E9qDy8D8TU2bFZ15Ym2hWeMMf8oVk+hRSaLZOUMTz5FkplH3w8JfyKa5BOi07fYBTDUSmpa9WM1tIlCF81Zw5Br/7jq9d8DlqXakDyun3XmYY85OrUIOd7CamCZ2oDxyapHr8Tne+A2IEdrxZeDVmdMiBeBIvsDm7fqO5MKOWUypCP1jiRmyQc2Y/kD6g8uzDSfQ9HGTzi9PiA/Pnk3dmOBw40vu+VbOcZSALgPKx9WZxdAm4mAaJ4MN81BxUfZfwQwm8zJ6fvywR1L2Oup2k0YjZ2eyFKZwXoKv5ciQlosvY5mR3gq7G7Jdg1g+aFnEV5DiOX7a4pVp3CuMgIXf94ru3bOHFZ8qQpwM10sh7jVyvohcbmGzOeMQMlcdVSyV51ZqlbvVqGOosqedQeSpL6GlUSOk5XBNoZtcx9PFtpqgQ84LU1C9JQoavE6WwY0bVQ7Fj5VA1dsl2M61fwjTlWi3dyE7xJhYvTVLYNjXh+uJE96saJe8+w7u3vF/toppwrOfU1ML+Zrxu4t/4htyPz2n7oL1+6sfnddO/0m/h60zhqzX/2/P5FX6CMQwIeeV1KkZIdiM7e8FkgGv7zit4R7aa9D7FbBb0KeHZx3tCqBjAX0EHdBzCn/H4Ngxvx/D39vYuHN9B426c/bs1p/IWPzspglocCeUvW/7MVKKIqqlfsjCZn42okgicXJX0mQG85jKUIr3RXLxgL1K3mytuf9dw7Jm3HB6fGoXii0WD9nBafi2dYR3jP/BYmg8='))

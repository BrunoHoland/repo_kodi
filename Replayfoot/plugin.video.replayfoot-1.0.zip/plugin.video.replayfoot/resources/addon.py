# -*- coding: UTF-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,sys
import urlresolver
from BeautifulSoup import BeautifulSoup
addon_base = 'replayfoot'
addon_id = 'plugin.video.replayfoot'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
dialog=xbmcgui.Dialog()
#
#
######################################################################################################
######################################################################################################
#
#
def CATEGORIES():
	addDir('Outras Competições','http://www.replayfoot.com/',3,artfolder + 'Outras Competies.png')
	addDir('Destaques das Ligas','http://www.replayfoot.com/',6,artfolder + 'Destaques das Ligas.png')
	addDir('Últimos Destaques','http://www.replayfoot.com/',2,artfolder + 'ltimos Destaques.png')
	addDir('Pesquisa','---',4,artfolder+'Pesquisa.png')
#
#
######################################################################################################
######################################################################################################
#
#
def pesquisa():
    keyb = xbmc.Keyboard('', 'Pesquisa...')
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText()
        parametro_pesquisa=urllib.quote(search)
        url = 'http://www.replayfoot.com/?s='+parametro_pesquisa
        listar_ultimos_videos(url)
		
		
def cleanTitle(title):
    title = title.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&#038;", "&").replace("&#39;", "'")
    title = title.replace("&#039;", "'").replace("&#8211;", "-").replace("&#8220;", "-").replace("&#8221;", "-").replace("&#8217;", "'")
    title = title.replace("&quot;", "\"").replace("&uuml;", "ü").replace("&auml;", "ä").replace("&ouml;", "ö")
    title = title.strip()
    return title	

	
def categorias_ligas():
	addDir('England','England',5,iconimage)
	addDir('Europe','Europe',5,iconimage)
	addDir('France','France',5,iconimage)
	addDir('Spain','Spain',5,iconimage)
	addDir('Germany','Germany',5,iconimage)
	addDir('Italy','Italy',5,iconimage)
	addDir('Preview','Preview',5,iconimage)
	addDir('Amistosos','Amistosos',5,iconimage)
	addDir('Italy','Italy',5,iconimage)
	addDir('Confederations Cup','Confederations Cup',5,iconimage)
	
	
def subCategorias_ligas(name):
	if 'England'==name:
		addDir('England','http://www.replayfoot.com/category/england/',2,iconimage)
		addDir('FA Cup','http://www.replayfoot.com/category/england/fa-cup/',2,iconimage)
		addDir('Community Shield','http://www.replayfoot.com/category/england/community-shield/',2,iconimage)
		addDir('Capital One Cup','http://www.replayfoot.com/category/england/capital-one-cup/',2,iconimage)
	if 'Europe'==name:
		addDir('Europe','http://www.replayfoot.com/category/europe/',2,iconimage)
		addDir('UEFA Super Cup','http://www.replayfoot.com/category/europe/uefa-super-cup/',2,iconimage)
	if 'France'==name:
		addDir('France','http://www.replayfoot.com/category/france/',2,iconimage)
		addDir('Coupe de france','http://www.replayfoot.com/category/france/coupe-de-france/',2,iconimage)
		addDir('Coupe de la league','http://www.replayfoot.com/category/france/coupe-de-la-league/',2,iconimage)
	if 'Spain'==name:
		addDir('Spain','http://www.replayfoot.com/category/spain/',2,iconimage)
		addDir('Supercopa de Espana','http://www.replayfoot.com/category/spain/supercopa-de-espana/',2,iconimage)
		addDir('Copa del Rey','http://www.replayfoot.com/category/spain/copa-del-rey/',2,iconimage)
	if 'Germany'==name:
		addDir('Germany','http://www.replayfoot.com/category/germany/',2,iconimage)
		addDir('DFB Pokal','http://www.replayfoot.com/category/germany/dfb-pokal/',2,iconimage)
	if 'Italy'==name:
		addDir('Italy','http://www.replayfoot.com/category/italia/',2,iconimage)
		addDir('Italy Cup','http://www.replayfoot.com/category/italia/coppa-italia/',2,iconimage)
	if 'Preview'==name:
		addDir('Preview','http://www.replayfoot.com/category/preview/',2,iconimage)
		addDir('England Preview','http://www.replayfoot.com/category/preview/england-preview/',2,iconimage)
		addDir('France Preview','http://www.replayfoot.com/category/preview/france-preview/',2,iconimage)
		addDir('Spain Preview','http://www.replayfoot.com/category/preview/spain-preview/',2,iconimage)
		addDir('Italy Preview','http://www.replayfoot.com/category/preview/italy/',2,iconimage)
		addDir('Germany Preview','http://www.replayfoot.com/category/preview/germany-preview/',2,iconimage)
	if 'Amistosos'==name:
		addDir('Amistosos','http://www.replayfoot.com/category/uncategorized/friendly/',2,iconimage)
	if 'Confederations Cup'==name:
		addDir('Confederations Cup','http://www.replayfoot.com/category/uncategorized/confederations-cup/',2,iconimage)	

		
def caterorias_ligas(url):
	addDir('Premier League','http://www.replayfoot.com/category/england/premier-league/',2,iconimage)
	addDir('La Liga','http://www.replayfoot.com/category/spain/la-liga/',2,iconimage)
	addDir('Serie A','http://www.replayfoot.com/category/italia/serie-a/',2,iconimage)
	addDir('Ligue 1','http://www.replayfoot.com/category/france/ligue-1/',2,iconimage)
	addDir('Bundesliga','http://www.replayfoot.com/category/germany/germany-bundesliga/',2,iconimage)
	addDir('UEFA Champions League','http://www.replayfoot.com/category/europe/uefa-champions-league/',2,iconimage)
	addDir('UEFA Europa League','http://www.replayfoot.com/category/europe/uefa-europa-league/',2,iconimage)	
	
	
def listar_ultimos_videos(url):
	link = abrir_url(url).replace('\n','').replace('\r','')
	match = re.compile('''<div class="videotitle"><h2 class="title"><a href="(.*?)" rel="bookmark" title=".*?highlights.*?">(.*?)\s*</a></h2></div>\s*<div class="thumb">\s*<a class="clip-link" data-id=".*?" title=".*?" href="http://www.replayfoot.com/.*?">\s*<span class="clip">\s*<img src="(.*?)" alt=".*?" /><span class="vertical-align"></span>\s*</span>\s*<span class="overlay"></span>\s*</a>\s*</div>\s*<div class="data">\s*<p class="stats">\s*(.*?)<span class="catright"><a href="http://www.replayfoot.com/category/.*?" rel="category tag">(.*?)</a></span>''').findall(link)
	for url,name,img,date,liga in match:
		name = cleanTitle(name)
		addDir(liga+'\n'+date+':    '+name,url,99,img)	#liga+'\n'+name+'      '+date
	reg = re.compile('''<span class='current'>(.*?)</span><a class="page larger" href="(.*?)">.*?</a>''').findall(link)
	for essa,proxima_pagina in reg:
		pro = int(essa)+1
		addDir('PÁGINA ATUAL:  '+essa+'  /  PRÓXIMA PAGINA:  '+str(pro),proxima_pagina,2,artfolder+'download.png')

	xbmc.executebuiltin("Container.SetViewMode(51)")
	
	
def player_addon(url,name,iconimage):#elif re.search('video_ext.php\?', videopage, re.DOTALL | re.IGNORECASE):
	link  = abrir_url(url)
	name = name.split('    ')[-1]
	try:
		dailymotion = re.compile('<iframe frameborder=".*?" width=".*?" height=".*?" src="//(.*?)" allowfullscreen></iframe>').findall(link)[0]
		if 'dailymotion.com' in dailymotion:
			quality_dailymotion(dailymotion,name,iconimage)
	except IndexError:
		pass
	try:
		streamable = re.compile('<iframe src="https://(streamable.*?)"').findall(link)[0]
		if 'streamable.com' in streamable:
			url = 'https://'+streamable
			quality_streamable(url,name,iconimage)
	except IndexError:
		pass
	try:
		if dailymotion =='' or streamable=='':
			xbmcgui.Dialog().ok(addon_base,'Desculpe sem links no momento !','Tente novamente mais tarde','')
			sys.exit()
	except UnboundLocalError:
		xbmcgui.Dialog().ok(addon_base,'Desculpe sem links no momento !','Tente novamente mais tarde','')
		sys.exit()
		
		
def quality_dailymotion(url,name,iconimage):
	url = url.split('/')[-1]
	link  = abrir_url('http://www.dailymotion.com/player/metadata/video/'+url)
	urls = []
	names = []
	match = re.compile('"(.*?)":"type":"application.*?x-mpegURL","url":"(.*?)"').findall(link.replace('[','').replace(']','').replace('{','').replace('}',''))
	for urlis,namis in match:
		names.append(urlis.replace('\/','/').split('"')[-1])
		urls.append(namis.replace('\/','/'))	
	opcao = xbmcgui.Dialog().select(name, names)
	if opcao>= 0:
		url = urls[opcao]
		xbmc.log('sadsadasdas5dasd4asdasdas-das-d-sad-sa-d-----------------------------------------------'+url)
		return dailymotion_player(url,name,iconimage)
	if opcao:
		sys.exit(0)
		
		
def dailymotion_player(url,name,iconimage):
	playlist = xbmc.PlayList(1)
	playlist.clear()
	url = abrir_url(url)
	liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	playlist.add('http://'+url.split('http://')[-1].split('.m3u8#')[0]+'.m3u8',liz)	
	xbmc.Player().play(playlist, liz, False)
	sys.exit()	
	
	
def quality_streamable(url,name,iconimage):
	link  = abrir_url(url)
	urls = []
	names = []
	match = re.compile('<a href="(.*?)" class=".*?" data-preset=".*?">\s*(.*?)\s*</a>').findall(link)
	for urlis,namis in match:
		urls.append(urlis)
		names.append(namis.replace('High','Qualidade Alta').replace('Low','Qualidade Baixa'))
	opcao = xbmcgui.Dialog().select(name, names)
	if opcao>= 0:
		#name = items_name[opcao]
		url = url + urls[opcao]
		#name = names[opcao]
		return streamable_player(url,name,iconimage)
		#sys.exit(0)
	if opcao:
		sys.exit(0)
		
		
def streamable_player(url,name,iconimage):
	html = abrir_url(url)
	link = re.compile('<source src="(.*?)" type="video/mp4" class="mp4-source"/>').findall(html)[0]
	link2 = 'https:'+link
	playlist = xbmc.PlayList(1)
	playlist.clear()
	try:
		listitem = xbmcgui.ListItem(name,thumbnailImage=iconimage)
		listitem.setInfo("Video", {"Title":name})
		listitem.setProperty('mimetype', 'video/mp4')    
		playlist.add(link2,listitem)
		xbmcPlayer = xbmc.Player()
		xbmcPlayer.play(playlist)
		sys.exit()
	except:
	    sys.exit()		

#
#
######################################################################################################
######################################################################################################
#
#		
def abrir_url(url):
	import mechanize,xbmcaddon
	browser = mechanize.Browser()
	browser.set_handle_robots(False)
	browser.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.6)')]
	browser.open(url)
	item =  browser.response().read()
	return item
	
	
def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok	
	
#
#
######################################################################################################
######################################################################################################
#
#
	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param   
		
		
params=get_params()
url=None
name=None
mode=None
iconimage=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
		
#
#
######################################################################################################
######################################################################################################
#
#
		
if mode==None or url==None or len(url)<1:
        CATEGORIES()
elif mode==2: listar_ultimos_videos(url)
elif mode==3: categorias_ligas()
elif mode==5: subCategorias_ligas(name)
elif mode==4: pesquisa()
elif mode==6: caterorias_ligas(url)
elif mode==99: player_addon(url,name,iconimage)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
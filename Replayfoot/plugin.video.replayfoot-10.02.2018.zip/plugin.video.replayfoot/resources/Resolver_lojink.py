# -*- coding: UTF-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,sys,base64,os,xbmcvfs

from metahandler import metahandlers

import re,urllib,json,time
addon_base = 'guisamples'
addon_id = 'plugin.video.guisamples'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
dialog=xbmcgui.Dialog()
#os.path.join(addonfolder, 'LivewebTV')
#
######################################################################################################
######################################################################################################
#
#

def CATEGORIES():#https://drive.google.com/open?id=0ByxImcC1icgMdjRCY3pRbUJ1LWs https://drive.google.com/get_video_info?docid=0ByxImcC1icgMdjRCY3pRbUJ1LWs
	addDir('Link openload','https://openload.co/embed/V3Vh_8vykNw',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Link dailymotion','http://www.dailymotion.com/embed/video/x6d14fn',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Link youtube','https://www.youtube.com/watch?v=dZUt4UEXOlk&t=147s',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Link vidoza.net','https://vidoza.net/mu637xcrz8nx.html',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Link ok.ru','https://ok.ru/videoembed/602213386768',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Link vimeo','https://vimeo.com/251397575',2,'dsadasdasdas',pasta=True,total=1,plot='')
	addDir('Extrair Arquivo Zips','Sem Link',3,'dsadasdasdas',pasta=True,total=1,plot='')
	#addDir2('181808','https://vimeo.com/251397575',2,'dsadasdasdas',1)

def idle():
    return execute('Dialog.Close(busydialog)')

addonInfo = xbmcaddon.Addon().getAddonInfo
	
def openSettings(query=None, id=addonInfo('id')):
    try:
        idle()
        execute = xbmc.executebuiltin
        execute('Addon.OpenSettings(%s)' % id)
        if query == None: raise Exception()
        c, f = query.split('.')
        execute('SetFocus(%i)' % (int(c) + 100))
        execute('SetFocus(%i)' % (int(f) + 200))
    except:
        return	
	
def convert_size(Arquivo):
	import math
	#from os.path import  getsize
	size = xbmcvfs.File(Arquivo).size()	
	if (size == 0):
		return '0B'
	size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
	i = int(math.floor(math.log(size,1024)))
	p = math.pow(1024,i)
	s = round(size/p,2)
	return '%s %s' % (s,size_name[i])
	
	
def sizes(filename):
    return xbmcvfs.File(filename).size()	
	
def Extrair_arquivo_Zip():
  #  season_urls = pickle.loads(url)
	import zipfile
	progress = xbmcgui.DialogProgress()	
	progress.create(addon_base)
	files = 'C:/Users/crotti/Desktop/skin.aczg-2.8.94.zip'#'C:\Users\crotti\Desktop\plugin.video.SaposatList.zip'
	file  = open(files, 'rb')
	z = zipfile.ZipFile(file)
	nFiles = float(len(z.infolist()))
	count  = 0
	index = 0
	stream_delay = 1
	num_urls = len(z.namelist())
	for name in z.namelist():
		count += 1
		percent = count / nFiles * 100#((index + 1) * 100) / num_urls
		progress.update( int(percent), "Arquivos encontrados %s"% num_urls, 'Tamanho do arquivo selecionado  %s' %convert_size(files), name)
		xbmc.sleep(stream_delay*100)
	progress.close()
	
	
def Lojink_resolver_dailymotion(url):
	#url = url.split('/')[-1]
	#url = re.compile('.+?//.+?/(?:embed|video)/(?:embed|video)/([0-9a-zA-Z-_]+)').findall(url)[0]
	url = re.compile('(?://|\.)(dailymotion\.com)/(?:video|embed|sequence|swf)(?:/video)?/([0-9a-zA-Z]+)').findall(url)[0]
	link  = abrir_url('http://www.dailymotion.com/player/metadata/video/'+url[1])
	urls = []
	names = []
	match = re.compile('"type":"video.+?mp4","url":"(.+?)"}.+?,"(.+?)"').findall(link)#.replace('[','').replace(']','').replace('{','').replace('}','')
	for url,name in match:
		names.append(name)
		urls.append(url.replace('\/','/'))	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_dailymotion', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)
	
def Lojink_resolver_Openload(url):
	id  = re.compile('//.+?/(?:embed|f)/([0-9a-zA-Z-_]+)').findall(url)[0]
	GET_URL = abrir_url('https://api.openload.co/1/streaming/get?file=%s'% id)
	xbmc.log('s-s--s-s-s-s-s-s-s--ss--s-s-s-s-s-s-s--s-s-s-s-s\n\n%s' % GET_URL)
	results = json.loads(GET_URL)
	items = results['result']['url']	
	return items.replace('\/','/').split('?mime=')[0]	
	
	
def Lojink_resolver_youtube(url):
	import yt
	_url_re = re.compile("""
    http(s)?://(\w+\.)?youtube.com
    (?:
        (?:
            /(watch.+v=|embed/|v/)
            (?P<video_id>[0-9A-z_-]{11})
        )
        |
        (?:
            /(user|channel)/(?P<user>[^/?]+)
        )
    )
""", re.VERBOSE)
	match = _url_re.match(url)
	items =  match.group("video_id")
	item = yt.Scrape(items)
	return item 
	
def abrir_urls(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Googlebot/2.1 (+http://www.googlebot.com/bot.html)')
	req.add_header('Referer','drive.google.com')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	
	
	
PROTOCOL = 'https://'	

#Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/3.0.195.38 Safari/532.0
#
#
def Lojink_resolver_vidoza(url):
	id = re.compile('(?://|\.)(vidoza\.net)/(?:embed-)?([0-9a-zA-Z]+)').findall(url)[0]
	link = abrir_url('https://vidoza.net/%s.html' % id[1])
	urls = []
	names = []
	match = re.compile('{file:"(.*?)",label:"(.*?)"}').findall(link)#.replace('[','').replace(']','').replace('{','').replace('}','')
	for url,name in match:
		names.append(name)
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_vidoza', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)

		
		
def abrir_url_ok_ru(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except IOError:#     except urllib2.HTTPError, e:
		print 'error'#dialog.notification(addon_base,'N�o foi possivel acessar o servidor.',icones)
		sys.exit(0)
		
def Lojink_resolver_ok_ru(url):
	html = abrir_url_ok_ru(url)
	h = ''.join(html.replace('\\','').replace('u0026','&').replace('&quot;',''))
	urls = []
	names = []
	qual_map = {'ultra': '2160', 'quad': '1440', 'full': '1080', 'hd': '720', 'sd': '480', 'low': '360', 'lowest': '240', 'mobile': '144'}
	match = re.compile('name:(.+?),url:(.+?),').findall(h)
	for name,url in match:
		url = url.replace('srcAg=UNKNOWN','srcAg=GECKO').replace('%3B',';').replace('ct=0','ct=4')
		names.append(qual_map.get(name))
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_ok_ru', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)


def Lojink_resolver_vimeo(url):
	id = re.compile('(?://|\.)(vimeo\.com)/(?:video/)?([0-9a-zA-Z]+)').findall(url)[0]
	link = abrir_url('https://player.vimeo.com/video/%s/config' % id[1])#.content#.result
	urls = []
	names = []
	match = re.compile('''{"profile":.*?,"width":.*?,"mime":"video.*?","fps":.*?,"url":"(.*?)","cdn":"akamai_interconnect","quality":"(.*?)","id":.*?,"origin":".*?","height":.*?}''').findall(link)
	for url,name in match:
		names.append(name)
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_vimeo', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)


		
def resolver_LOJINK(url):
	resolvers = ['openload','dailymotion','youtube','vidoza','ok','vimeo']
	if any(x in url for x in resolvers):
		if 'dailymotion' in url:
			return Lojink_resolver_dailymotion(url)
		elif 'openload' in url:
			return Lojink_resolver_Openload(url)
		elif 'youtube' in url:
			return Lojink_resolver_youtube(url)
		elif 'vidoza' in url:
			return Lojink_resolver_vidoza(url)
		elif 'ok' in url:
			return Lojink_resolver_ok_ru(url)
		elif 'vimeo' in url:
			return Lojink_resolver_vimeo(url)
	
	
	else:
		xbmcgui.Dialog().ok('resolver_LOJINK','Desculpe n�o foi possivel resolver o link','','')
		sys.exit(0)
	
def streamable_player(url,name,iconimage):
	link2 = resolver_LOJINK(url)
	pl=xbmc.PlayList(1)
	pl.clear()	
	listitem = xbmcgui.ListItem('sadsadsadsa', thumbnailImage='asdsadsad')
	xbmc.PlayList(1).add(link2, listitem)
	xbmc.Player().play(pl)	
	sys.exit(0)
	
	
#
#
######################################################################################################
#							DESATIVADOS
######################################################################################################
#
#	
itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
                         '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
                         '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
                         '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
                         '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
                         '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
                         '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
                         '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
                         '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
                         '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}	
def Lojink_resolver_Google(url):
    id = re.compile('https?://(.*?(?:\.googlevideo|(?:plus|drive|get|docs)\.google|google(?:usercontent|drive|apis))\.com)/(.*?(?:videoplayback\?|[\?&]authkey|host/)*.+)').findall(url)[0]
    prelink = prelink = 'https://drive.google.com/get_video_info?docid=%s' % id[1].split('/d/')[-1].split('id=')[-1]
    Link_append = []
    Name_append = []
    # https://drive.google.com/file/d/0B8kCEtrnzKhDLTNmYzZBSnpPeEE/edit?pli=1
    vid = urlparse.urlparse(url).path.split("/")[-2]
    print "[gdrive] vid = %s" % vid
    # direct link for uploaded video, non-seekable..
    # return [{"provider":"gdrive", "url":"https://googledrive.com/host/%s"% vid, "quality":"???"}]

    # ydl gdrive, seekable urls..
    video_req = urllib2.Request(url)
    video_req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36")
    video_data = urllib2.urlopen(video_req).read().decode('unicode_escape')
    salve_link(video_data.encode('unicode_escape'))
    # print "[gdrive]", video_data
    itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
                         '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
                         '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
                         '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
                         '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
                         '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
                         '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
                         '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
                         '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
                         '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}
    fmt_list = re.search(r'"fmt_list"\s*,\s*"([^"]+)', video_data).group(1)
    fmt_list = fmt_list.split(',')
    print "[gdrive] fmt_list = %r" % fmt_list
    fmt_stream_map = re.search(r'"fmt_stream_map"\s*,\s*"([^"]+)', video_data).group(1)
    fmt_stream_map = fmt_stream_map.split(',')
    #print "[gdrive] fmt_stream_map = %r, len=%d" % (fmt_stream_map, len(fmt_stream_map))
    result = []
    for i in range(len(fmt_stream_map)):
        fmt_id, fmt_url = fmt_stream_map[i].split('|')
        fmt = itag_map.get(fmt_id)
        extension = fmt# and fmt['ext']
        resolution = fmt_list[i].split('/')[1]
        width, height = resolution.split('x')
        #result.append({"provider":"gdrive", "url":fmt_url, "quality": height+"p", "ext":extension})

        Link_append.append(fmt_url)
        Name_append.append(height)
    opcao = xbmcgui.Dialog().select('Lojink_resolver_dailymotion', Name_append)
    if opcao>= 0:
        url = Link_append[opcao]
        return url
    if opcao:
        sys.exit(0)	

#
#
######################################################################################################
######################################################################################################
#
#		
def abrir_url(url):
	import mechanize,xbmcaddon
	browser = mechanize.Browser()
	browser.set_handle_robots(False)
	browser.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.6)')]
	browser.open(url)
	item =  browser.response().read()
	return item

def salve_info(url):
	lib = os.path.join(addonfolder, 'LivewebTV')
	b = open(lib, "w")
	b.write(url)
	b.close()
	
	
def addDir2(name,url,mode,iconimage,itemcount):
        name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        splitName=name.partition('(')
        simplename=""
        simpleyear=""
        if len(splitName)>0:
            simplename=splitName[0]
            simpleyear=splitName[2].partition(')')
        if len(simpleyear)>0:
            simpleyear=simpleyear[0]
	    mg = metahandlers.MetaData(tmdb_api_key="36c1c59f0524a63e772b90c3778fb097")
	    meta = mg.get_meta('movie', name=simplename ,tmdb_id=name)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=iconimage
        name = '[B][COLOR white]' + name + '[/COLOR][/B]'
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % sys.argv[0], urllib.quote_plus(meta['trailer']), urllib.quote_plus(name)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image',fanart)
        if mode==100 or mode==101:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok	
	
def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok	
	
#
#
######################################################################################################
######################################################################################################
#
#
	
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param   
		
		
params=get_params()
url=None
name=None
mode=None
iconimage=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass

if not url is None:
    xbmc.log("URL: "+str(url.encode('utf-8')))
xbmc.log("Name: "+str(name))

		
#
#
######################################################################################################
######################################################################################################
#
#
		
if mode==None or url==None or len(url)<1:
        CATEGORIES()
elif mode==2:  streamable_player(url,name,iconimage)
elif mode==3:  Extrair_arquivo_Zip()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
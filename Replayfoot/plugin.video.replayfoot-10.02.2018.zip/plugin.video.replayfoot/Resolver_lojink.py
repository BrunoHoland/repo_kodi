# -*- coding: UTF-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,sys,base64,os,xbmcvfs
import re,urllib,json,time
addon_base = 'Lojink_resolver'
dialog=xbmcgui.Dialog()

		
def resolver_LOJINK(url):
	resolvers = ['openload','dailymotion','youtube','vidoza','ok','vimeo','streamable']
	if any(x in url for x in resolvers):
		if 'dailymotion' in url:
			return Lojink_resolver_dailymotion(url)
		elif 'openload' in url:
			return Lojink_resolver_Openload(url)
		elif 'youtube' in url:
			return Lojink_resolver_youtube(url)
		elif 'vidoza' in url:
			return Lojink_resolver_vidoza(url)
		elif 'ok' in url:
			return Lojink_resolver_ok_ru(url)
		elif 'vimeo' in url:
			return Lojink_resolver_vimeo(url)
		elif 'streamable' in url:
			return Lojink_resolver_streamable(url)
	
	
	else:
		xbmcgui.Dialog().ok('resolver_LOJINK','Desculpe n�o foi possivel resolver o link','','')
		sys.exit(0)

def abrir_url(url):
	import mechanize,xbmcaddon
	browser = mechanize.Browser()
	browser.set_handle_robots(False)
	browser.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.6)')]
	browser.open(url)
	item =  browser.response().read()
	return item
		
		
def abrir_url_ok_ru(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except IOError:#     except urllib2.HTTPError, e:
		print 'error'#dialog.notification(addon_base,'N�o foi possivel acessar o servidor.',icones)
		sys.exit(0)

		

def Lojink_resolver_dailymotion(url):
	#url = url.split('/')[-1]
	#url = re.compile('.+?//.+?/(?:embed|video)/(?:embed|video)/([0-9a-zA-Z-_]+)').findall(url)[0]
	url = re.compile('(?://|\.)(dailymotion\.com)/(?:video|embed|sequence|swf)(?:/video)?/([0-9a-zA-Z]+)').findall(url)[0]
	link  = abrir_url('http://www.dailymotion.com/player/metadata/video/'+url[1])
	urls = []
	names = []
	match = re.compile('"type":"video.+?mp4","url":"(.+?)"}.+?,"(.+?)"').findall(link)#.replace('[','').replace(']','').replace('{','').replace('}','')
	for url,name in match:
		names.append(name)
		urls.append(url.replace('\/','/'))	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_dailymotion', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)
	
def Lojink_resolver_Openload(url):
	id  = re.compile('//.+?/(?:embed|f)/([0-9a-zA-Z-_]+)').findall(url)[0]
	GET_URL = abrir_url('https://api.openload.co/1/streaming/get?file=%s'% id)
	xbmc.log('s-s--s-s-s-s-s-s-s--ss--s-s-s-s-s-s-s--s-s-s-s-s\n\n%s' % GET_URL)
	results = json.loads(GET_URL)
	items = results['result']['url']	
	return items.replace('\/','/').split('?mime=')[0]	
	
	
def Lojink_resolver_youtube(url):
	import yt
	_url_re = re.compile("""
    http(s)?://(\w+\.)?youtube.com
    (?:
        (?:
            /(watch.+v=|embed/|v/)
            (?P<video_id>[0-9A-z_-]{11})
        )
        |
        (?:
            /(user|channel)/(?P<user>[^/?]+)
        )
    )
""", re.VERBOSE)
	match = _url_re.match(url)
	items =  match.group("video_id")
	item = yt.Scrape(items)
	return item 
	
def Lojink_resolver_vidoza(url):
	id = re.compile('(?://|\.)(vidoza\.net)/(?:embed-)?([0-9a-zA-Z]+)').findall(url)[0]
	link = abrir_url('https://vidoza.net/%s.html' % id[1])
	urls = []
	names = []
	match = re.compile('{file:"(.*?)",label:"(.*?)"}').findall(link)#.replace('[','').replace(']','').replace('{','').replace('}','')
	for url,name in match:
		names.append(name)
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_vidoza', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)


def Lojink_resolver_ok_ru(url):
	html = abrir_url_ok_ru(url)
	h = ''.join(html.replace('\\','').replace('u0026','&').replace('&quot;',''))
	urls = []
	names = []
	qual_map = {'ultra': '2160', 'quad': '1440', 'full': '1080', 'hd': '720', 'sd': '480', 'low': '360', 'lowest': '240', 'mobile': '144'}
	match = re.compile('name:(.+?),url:(.+?),').findall(h)
	for name,url in match:
		url = url.replace('srcAg=UNKNOWN','srcAg=GECKO').replace('%3B',';').replace('ct=0','ct=4')
		names.append(qual_map.get(name))
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_ok_ru', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)


def Lojink_resolver_vimeo(url):
	id = re.compile('(?://|\.)(vimeo\.com)/(?:video/)?([0-9a-zA-Z]+)').findall(url)[0]
	link = abrir_url('https://player.vimeo.com/video/%s/config' % id[1])#.content#.result
	urls = []
	names = []
	match = re.compile('''{"profile":.*?,"width":.*?,"mime":"video.*?","fps":.*?,"url":"(.*?)","cdn":"akamai_interconnect","quality":"(.*?)","id":.*?,"origin":".*?","height":.*?}''').findall(link)
	for url,name in match:
		names.append(name)
		urls.append(url)	
	opcao = xbmcgui.Dialog().select('Lojink_resolver_vimeo', names)
	if opcao>= 0:
		url = urls[opcao]
		return url
	if opcao:
		sys.exit(0)

	
def Lojink_resolver_streamable(url):
	link  = abrir_url(url)
	urls = []
	names = []
	match = re.compile('{"status".*?"height": (.*?), "width".*?"url": "(.*?)",').findall(link)
	for namis, urlis in match:
		urls.append(urlis)
		names.append(namis.replace('High','Qualidade Alta').replace('Low','Qualidade Baixa'))
	opcao = xbmcgui.Dialog().select('Lojink_resolver_streamable', names)
	if opcao>= 0:
		#name = items_name[opcao]
		url = urls[opcao]
		#html = abrir_url(url)
		#link = re.compile('<source src="(.*?)" type="video/mp4" class="mp4-source"/>').findall(html)[0]
		#name = names[opcao]
		return 'https:'+url
		#sys.exit(0)
	if opcao:
		sys.exit(0)
		
######################################################################################################
#							DESATIVADOS
######################################################################################################
#
#	
itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
                         '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
                         '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
                         '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
                         '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
                         '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
                         '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
                         '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
                         '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
                         '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}	
def Lojink_resolver_Google(url):
    id = re.compile('https?://(.*?(?:\.googlevideo|(?:plus|drive|get|docs)\.google|google(?:usercontent|drive|apis))\.com)/(.*?(?:videoplayback\?|[\?&]authkey|host/)*.+)').findall(url)[0]
    prelink = prelink = 'https://drive.google.com/get_video_info?docid=%s' % id[1].split('/d/')[-1].split('id=')[-1]
    Link_append = []
    Name_append = []
    # https://drive.google.com/file/d/0B8kCEtrnzKhDLTNmYzZBSnpPeEE/edit?pli=1
    vid = urlparse.urlparse(url).path.split("/")[-2]
    print "[gdrive] vid = %s" % vid
    video_req = urllib2.Request(url)
    video_req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36")
    video_data = urllib2.urlopen(video_req).read().decode('unicode_escape')
    salve_link(video_data.encode('unicode_escape'))
    fmt_list = re.search(r'"fmt_list"\s*,\s*"([^"]+)', video_data).group(1)
    fmt_list = fmt_list.split(',')
    print "[gdrive] fmt_list = %r" % fmt_list
    fmt_stream_map = re.search(r'"fmt_stream_map"\s*,\s*"([^"]+)', video_data).group(1)
    fmt_stream_map = fmt_stream_map.split(',')
    #print "[gdrive] fmt_stream_map = %r, len=%d" % (fmt_stream_map, len(fmt_stream_map))
    result = []
    for i in range(len(fmt_stream_map)):
        fmt_id, fmt_url = fmt_stream_map[i].split('|')
        fmt = itag_map.get(fmt_id)
        extension = fmt# and fmt['ext']
        resolution = fmt_list[i].split('/')[1]
        width, height = resolution.split('x')
        #result.append({"provider":"gdrive", "url":fmt_url, "quality": height+"p", "ext":extension})

        Link_append.append(fmt_url)
        Name_append.append(height)
    opcao = xbmcgui.Dialog().select('Lojink_resolver_dailymotion', Name_append)
    if opcao>= 0:
        url = Link_append[opcao]
        return url
    if opcao:
        sys.exit(0)	

#
#
######################################################################################################
######################################################################################################
#
#		
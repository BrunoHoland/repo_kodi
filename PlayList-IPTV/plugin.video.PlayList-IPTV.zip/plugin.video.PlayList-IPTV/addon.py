# -*- coding: UTF-8 -*-

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,io,zlib,base64,shutil,subprocess,xbmcvfs,glob,json,traceback,urlparse
import urlresolver
from BeautifulSoup import BeautifulSoup
from time import sleep

addon_base = 'PlayList [COLOR dodgerblue]IPTV[/COLOR]'#Link List Lojink
addon_id = 'plugin.video.PlayList-IPTV'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
profile = xbmc.translatePath(selfAddon.getAddonInfo('profile').decode('utf-8'))
addonInfo = xbmcaddon.Addon().getAddonInfo
dialog = xbmcgui.Dialog()  
source_file = os.path.join(profile, 'source_file')
favoritos = os.path.join(profile, 'favoritos')
save_list = os.path.join(profile, 'save_list')
artfolder = addonfolder + '/icones/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
getSetting = selfAddon.getSetting
player_f4m = getSetting('player_f4m')
group_list = getSetting('group_list')  
Exportar_Packs = getSetting('Exportar_Packs')
Importa_Packs = getSetting('Importa_Packs')	
######################################################################################################################################################################
	
if os.path.exists(profile)==False:
    os.mkdir(profile)#os.makedirs	
	
if os.path.exists(save_list)==False:
    os.mkdir(save_list)#os.makedirs
	
def MENU_OPCOES():
	menu = ['Exportar Lista para Armazenamento local','Importar Pack local','Excluir Todas as Listas','Importa Pack online','Exportar Pack para servidor']
	option = dialog.select(addon_base,menu)
	if option==0:
		linkas = Exportar_Packs
		if linkas=='':
			choice = dialog.yesno(addon_base, 'Ops...Você Esqueceu de Selecionar o Local Para Exportar as Listas','Deseja Selecionar o Local do Arquivo Agora?',yeslabel='Sim',nolabel='Não')
			if choice == 1:
				openSettings('1.0')
			else:
				sys.exit()
		else:
			shutil.copy2(source_file,linkas)
			dialog.ok(addon_base, "LISTAS EXPORTADAS COM SUCESSO")
			sys.exit()		
	elif option==1:
		linkas = Importa_Packs
		if linkas=='':
			choice = dialog.yesno(addon_base, 'Ops...Você Esqueceu de Selecionar a Lista Para Importar','Deseja Selecionar o Arquivo Agora?',yeslabel='Sim',nolabel='Não')
			if choice == 1:
				openSettings('1.0')
			else:
				sys.exit()				
		else:
			item = local_online(linkas)
			if '"url"'in item:
				f = open(source_file,'a')
				f.write(item)	
				f.close()
				dialog.ok(addon_base, "Listas Importadas Com Sucesso",'Listas Encontradas No Pack ==> %s' % item.count('"url"'),'')
				xbmc.executebuiltin("Container.Refresh")	
				sys.exit()
			else:
				dialog.notification('','Nenhuma Lista Encontrada No Pack Selecionado!',icones)
				sys.exit()
	elif option==2:
		choice = dialog.yesno(addon_base, 'Deseja Apagar Todas as Listas Armazenadas ?','',yeslabel='Sim',nolabel='Não')
		if choice == 1:
			os.remove(source_file)
			xbmc.executebuiltin("Container.Refresh")
			sys.exit()
		else:
			sys.exit()#https://pastebin.com/raw/MUeiLLEN
	elif option==3:
		token = GetKeyboardText('Insira o id do Pack')
		if len(token) > 1:
			try:
				item =  urllib2.urlopen('https://pastebin.com/raw/%s' % token).read()	
			except:
				dialog.ok(addon_base, "Nenhuma lista encontrada no Pack",'id do Pack==>  [COLOR dodgerblue]%s[/COLOR]' % token,'')
				sys.exit()
			items = item.decode('base64')
			dialog.ok(addon_base, "Pack Importada Com Sucesso",'Listas Encontradas No Pack ==> %s' % items.count('"url"'),'')
			if '"url"'in items:
				f = open(source_file,'a')
				f.write(items)	
				f.close()		
				xbmc.executebuiltin("Container.Refresh")	
				sys.exit()
			else:
				dialog.ok(addon_base, "Nenhuma lista encontrada no Pack",'id do Pack==>  [COLOR dodgerblue]%s[/COLOR]' % token,'')
				sys.exit()
	elif option==4:
		Upload_Pack()
	
	elif option:
		sys.exit()	

def Salvar_Listas(url,name):
	import downloader
	dp = xbmcgui.DialogProgress()
	dp.create("ADDON SELECIONADO","BAIXANDO ",'', 'POR FAVOR ESPERE')	
	lib=os.path.join(save_list, name)
	downloader.download(url, lib, dp)
		
def CATEGORIES():#
	if os.path.exists(favoritos)==True:
		addDir('FAVORITOS'.title(),'-',27,artfolder+'FAVORITOS.png')
	addDir('ADD-ON SETTINGS'.title(),'-',29,artfolder+'ADD-ON SETTINGS.png')
	addDir('LISTA M3U ONLINE  <|>  LISTA M3U LOCAL'.title(),'-',6,artfolder+'LISTAs.png',True)
	addDir('[B]--------------------------------------------------------------------------------------------[/B]','None',2090,artfolder+'--------------------------------------------------------------.png')
	if os.path.exists(source_file)==True:
		sources = json.loads(open(source_file,"r").read().replace('}][{','},{').replace('[][{','[{'))
		sources.reverse()
		for i in sources:
			name = i['name'].encode('utf-8')
			url = i['url'].encode('utf-8')
			addDir(name,url,5,icones)	
		
def Listar_Favoritos():
	sources = json.loads(open(favoritos,"r").read())
	for i in sources:
		name = i['name'].encode('utf-8')
		url = i['url'].encode('utf-8')
		iconimage = i['iconimage'].encode('utf-8')
		mode = i['mode'].encode('utf-8')
		add_Dir(name,url,mode,iconimage)
				
		
############################################################################################################
#                                 LISTAR LISTAS	                                                		   #
############################################################################################################

def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match		
	
def m3u2list(url):
	response = local_online(url)
	response = response.replace('#AAASTREAM:','#A:')
	response = response.replace('#EXTINF:','#A:')	
	matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$', re.M).findall(response)
	li = []
	for params, display_name, url in matches:
		item_data = {"params": params, "display_name": display_name.strip(), "url": url.strip()}
		li.append(item_data)
	chList = []
	for channel in li:
		item_data = {"display_name": channel["display_name"], "url": channel["url"]}
		matches=re.compile(' (.+?)="(.+?)"').findall(channel["params"])
		for field, value in matches:
			item_data[field.strip().lower().replace('-', '_')] = value.strip()
			if 'group-title' in field:
				nuero = response.count('group-title="%s"' % value.split('title="')[-1].split('",')[0])
				item_data['Categoria'] = nuero
			
		chList.append(item_data)
	return chList
		
group_lists = selfAddon.getSetting('group_list')
grupo = {'SIM': 'true','NÃO':''}
makeGroups = grupo[group_lists]
	

		
def listar_m3u(url,name):
#	if os.path.exists(save_list+'\\'+name)==True:
#		choice = xbmcgui.Dialog().yesno(addon_base,'O sistema detectou essa lista salva no sistema deseja abrir lista salva ou lista do servidor ?',yeslabel='lista do servidor',nolabel='lista salva')
#		if choice == 1:
#			url = url
#		elif choice == 0:
#			url = save_list+'\\'+name	
	link = m3u2list(url)
	gListIndex=-1	
	groupChannels = []
	for channel in link:
		if makeGroups:
			matches = [groupChannels.index(x) for x in groupChannels if len(x) > 0 and x[0].get("group_title", x[0]["display_name"]) == channel.get("group_title", channel["display_name"])]
		if makeGroups and len(matches) == 1:
			groupChannels[matches[0]].append(channel)
		else:
			groupChannels.append([channel])
	for channels in groupChannels:
		idx = groupChannels.index(channels)
		if gListIndex > -1 and gListIndex != idx:
			continue
		isGroupChannel = gListIndex < 0 and len(channels) > 1
		chs = [channels[0]] if isGroupChannel else channels
		for channel in chs:
			name = channel["display_name"] if not isGroupChannel else channel.get("group_title", channel["display_name"])
			
			if isGroupChannel:
				categoria = '{0}'.format(name.split('title="')[-1].split('",')[0])
				contar = channel.get("Categoria")
				chUrl = url
				try:
					image = channel.get("tvg_logo")
					if image.startswith('http'):
						logo = image
					else:
						logo = icones		
				except AttributeError:
					logo = icones		
				
				nome = categoria+'  -  %s' % contar
				if not  '-  None' in nome:
					addDir(nome,chUrl,24,logo)
			else:
				chUrl = channel["url"]
				image = channel.get("tvg_logo", channel.get("logo", ""))
				if image.startswith('http'):
					logo = image
				else:
					logo = icones
				if 'magnet:?' in chUrl:
					name = name+'  [Torrent]' 
				else:
					name = name					
				addDir(name, chUrl, 15, logo)

def listar_m3u_categorias(name,url,iconimage):
			categorias = name.split('  -  ')[0]
			link = m3u2list(url)
			for channel in link:
				name = channel["display_name"]
				chUrl = channel["url"]
				categoria = channel.get("group_title")
				image = channel.get("tvg_logo", channel.get("logo", ""))
				if image.startswith('http'):
					logo = image
				else:
					logo = icones
				if 'magnet:?' in chUrl:
					name = name+'  [Torrent]' 
				else:
					name = name
				if categorias==categoria:
					addDir(name, chUrl, 15, logo)
############################################################################################################
#                                           PLAYER                                                
############################################################################################################	
libDir = os.path.join(addonfolder,'lib')
sys.path.insert(0, libDir)
import F4mProxy


def player_addon(name,url,iconimage):
	if url.startswith('acestream://'):
		url = 'plugin://program.plexus/?mode=1&url={0}&name={1}&iconimage={2}'.format(url, name, iconimage)
	if '.m3u8' in url or '.ts' in url and not 'plugin://':#123
		if selfAddon.getSetting('player_f4m') == "ATIVAR":
			if '.f4m' in url:
				url = 'plugin://plugin.video.f4mTester/?url='+url
			elif '.m3u8' in url:
				url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+name+'&url='+url+'&iconImage='+iconimage	
			elif '.ts' in url:
				url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+name+'&url='+url+'&iconImage='+iconimage			
				sys.exit()
	if 'magnet:?xt' in url:	#'xt=urn:btih:([^&/]+)
		if selfAddon.getSetting('player_torrent') == "Quasar":
			url = 'plugin://plugin.video.quasar/play?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Pulsar":
			url = 'plugin://plugin.video.pulsar/play?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Yatp":
			url = 'plugin://plugin.video.yatp/?action=play&torrent={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Torrenter":
			url = 'plugin://plugin.video.torrenter/?action=playSTRM&url={0}&not_download_only=True'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "XbmcTorrent":
			url = 'plugin://plugin.video.xbmctorrent/play/{0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Torrentin":
			url = 'plugin://plugin.video.torrentin/?uri={0}'.format(urllib.quote_plus(url))
			
		elif selfAddon.getSetting('player_torrent') == "Ace Stream (apk)":
			if xbmc.getCondVisibility('system.platform.android'):
				xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media","android.intent.action.VIEW","","'+url+'")')
			else:
				dialog.ok(addon_base,  "FUNCIONA APENAS EM SISTEMAS ANDROID !!!".decode('unicode_escape'),'')
				sys.exit(0)		


	try:
		if urlresolver.HostedMediaFile(url):
			listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
			xbmc.Player().play(item=urlresolver.resolve(url), listitem=listItem)		
			sys.exit()
		else:
			listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
			xbmc.Player().play(item=url, listitem=listItem)			
			sys.exit()
		
	except urlresolver.resolver.ResolverError:
		listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
		xbmc.Player().play(item=url, listitem=listItem)
		sys.exit()
			
############################################################################################################
#                   	REMOVER E ADICIONAR AOS FAVORITOS		                                           #
############################################################################################################	
def Adicionar_Favoritos(name,url,iconimage):
	mode = url.split('##')[-1]
	url = url.split('##')[0]
	source_media = {}
	source_media['name'] = name
	source_media['url'] = url
	source_media['iconimage'] = iconimage
	source_media['mode'] = mode
	if os.path.exists(favoritos)==False:
		source_list = []
		source_list.append(source_media)
		b = open(favoritos,"a")
		b.write(json.dumps(source_list))
		b.close()
	else:
		sources = json.loads(open(favoritos,"r").read())
		sources.append(source_media)
		b = open(favoritos,"w")
		b.write(json.dumps(sources))
		b.close()	

def Remover_Favoritos(name):
        sources = json.loads(open(favoritos,"r").read())
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == name:
                    del sources[index]
                    b = open(favoritos,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['name'] == name:
                    del sources[index]
                    b = open(favoritos,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
		dialog.notification(addon_base,'Item removido da lista de Favoritos.',icones)	
        xbmc.executebuiltin("XBMC.Container.Refresh")
		
def Remover_Source(name):
        sources = json.loads(open(source_file,"r").read().replace('}][{','},{'))
        for index in range(len(sources)):
            if isinstance(sources[index], list):
                if sources[index][0] == name:
                    del sources[index]
                    b = open(source_file,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
            else:
                if sources[index]['name'] == name:
                    del sources[index]
                    b = open(source_file,"w")
                    b.write(json.dumps(sources))
                    b.close()
                    break
		dialog.notification(addon_base,'lista removida.',icones)	
        xbmc.executebuiltin("XBMC.Container.Refresh")

############################################################################################################
#                                           FUNÇOES FEITAS                                                 #
############################################################################################################	
		
def m3u_Local_Online():
	option = dialog.select('Adicionar Lista'.title(),['lista Online'.title(),'lista Local'.title()])
	if option == 0:
		ADD_LISTA_ONLINE()
	if option == 1:
		ADD_LISTA_LOCAL()	
	elif option:
		sys.exit()		
	
def ADD_LISTA_ONLINE():
	try:
		url = GetKeyboardText(title='link da Lista M3u Online'.title(),defaultText='')
		if '/' in url or '\\' in url:
			pass
		else:
			dialog.ok(addon_base,'não foi possivel adicionar a lista'.title().decode('utf-8'))
			sys.exit(0)		
		name = GetKeyboardText('Nome da Lista M3u Online',defaultText = '%s' % os.path.basename(url))
		if len(name) > 1:
			source_media = {}
			source_media['name'] = name
			source_media['url'] = url
			source_media['fanart'] = fanart
			if os.path.exists(source_file)==False:
				source_list = []
				source_list.append(source_media)
				b = open(source_file,"a")
				b.write(json.dumps(source_list))
				b.close()
			else:
				sources = json.loads(open(source_file,"r").read())
				sources.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(sources))
				b.close()	
			xbmc.executebuiltin("Container.Refresh")
			sys.exit()
		else:
			dialog.notification(addon_base,'não foi possivel adicionar a lista'.title().decode('utf-8'),icones)
			sys.exit(0)
	except: 
		xbmc.log('%s' % traceback.print_exc())
		sys.exit()
		

def ADD_LISTA_LOCAL():
	try:
		url = dialog.browse(1, '[B]LISTA M3U LOCAL[/B]', 'myprograms', '', False, False, '')
		if '/' in url or '\\' in url:
			pass
		else:
			dialog.ok(addon_base,'não foi possivel adicionar a lista'.title().decode('utf-8'))
			sys.exit()		
		name = GetKeyboardText('[B]NOME DA LISTA M3U LOCAL[/B]',defaultText = '%s' % os.path.basename(url))
		if len(name) > 1:
			source_media = {}
			source_media['name'] = name
			source_media['url'] = url
			source_media['fanart'] = fanart
			if os.path.exists(source_file)==False:
				source_list = []
				source_list.append(source_media)
				b = open(source_file,"a")
				b.write(json.dumps(source_list))
				b.close()
			else:
				sources = json.loads(open(source_file,"r").read())
				sources.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(sources))
				b.close()	
			xbmc.executebuiltin("Container.Refresh")
			sys.exit()
		else:
			dialog.notification(addon_base,'não foi possivel adicionar a lista'.title().decode('utf-8'),icones)
			sys.exit(0)	
	except: 
		xbmc.log('%s' % traceback.print_exc())
		sys.exit()
	
def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text = "" if not keyboard.isConfirmed() else keyboard.getText()
	return text
		
		
def idle():
    return xbmc.executebuiltin('Dialog.Close(busydialog)')
	
def openSettings(query=None, id=addonInfo('id')):
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % id)
        if query == None: raise Exception()
        c, f = query.split('.')
        xbmc.executebuiltin('SetFocus(%i)' % (int(c) + 100))
        xbmc.executebuiltin('SetFocus(%i)' % (int(f) + 200))
    except:
        traceback.print_exc()					
	
def Upload_Pack():
	API_KEY = '66554d00fa20ba30f4f8a5da7c5bfb2f'
	BASE_URL = 'http://pastebin.com/api/api_post.php'
	EXPIRATION = '1Y'
	name = 'pastebin'
	url = '/api/api_post.php'

	link = open(source_file,'r').read()
	base_Pack = link.encode('base64')
	data = {'api_dev_key': API_KEY, 'api_option': 'paste', 'api_paste_code': base_Pack, 'api_paste_name': 'Import Pack kodi online','api_paste_private': 1, 'api_paste_expire_date': '1Y'}
	data = urllib.urlencode(data)
	#headers = {}
	#headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
	#headers['Referer'] = BASE_URL
	req = urllib2.Request(BASE_URL, data)
	try:
		res = urllib2.urlopen(req)
		html = res.read()
		xbmc.log( 'ssssssssssssssssssssssssssssssssssss %s' % html)
		xbmc.log(html)
		if html.startswith('http'):
			xbmc.log( 'ssssssssssssssssssssssssssssssssssss %s' % html)
			dialog.ok(addon_base,'Lista importada com sucesso !','id do Pack==>  [COLOR dodgerblue]%s[/COLOR]' % os.path.basename(html),'')
			sys.exit()
		if 'Post limit, maximum pastes per 24h reached' in html:
			dialog.ok(addon_base,'Limite de postagem, pastas máximas por 24h alcançadas','Tente novamente em 24 horas','')
			sys.exit()
		else:
			sys.exit()
		if html.upper().startswith('BAD API REQUEST'):
			dialog.ok(addon_base,'Bad API Request','','')
			sys.exit()
		else:
			sys.exit()	
	except Exception as e:
		print(e)
		
	
def local_online(url):
	if url.startswith('http'):
		try:
			req = urllib2.Request(url)
			req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36')
			response = urllib2.urlopen(req)
			link=response.read()
			response.close()
			return link
		except  urllib2.HTTPError, e:
			dialog.notification('','Não Foi Possível Acessar o Servidor.\nError: '+str(e),icones)
			sys.exit(0)
	else:
		try:
			content = open(url, 'r')
			link2 = content.read()
			content.close()
			return link2	
		except IOError , e:
			dialog.notification('','Não Foi Possível Acessar o Arquivo.\nError: '+str(e.args[-1]),icones)
			sys.exit(0)
	
def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	if mode==5:#not mode==11 and  not mode==15 and not mode==999 and not mode==6 and not mode==24 and not mode==27:
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	else:
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	cmItems = []
	if mode==15 or mode==24:
		cmItems.append(('Adicionar Aos Favoritos\n%s'%addon_base, 'XBMC.RunPlugin(%s?url=%s&mode=26&name=%s&iconimage=%s)'%(sys.argv[0],urllib.quote_plus(url+'##%s'%mode),urllib.quote_plus(name),urllib.quote_plus(iconimage))))
	if mode==5:
		cmItems.append(('Remover Lista\n%s'% addon_base, 'XBMC.RunPlugin(%s?url=%s&mode=25&name=%s&iconimage=%s)'%(sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(name),urllib.quote_plus(iconimage))))
		#cmItems.append(('Salvar Lista\n%s'% addon_base, 'XBMC.RunPlugin(%s?url=%s&mode=30&name=%s&iconimage=%s)'%(sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(name),urllib.quote_plus(iconimage))))
	liz.addContextMenuItems(cmItems, replaceItems=False)
	liz.setProperty('fanart_image', fanart)
	liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok	

def add_Dir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	if mode==5:#not mode==11 and  not mode==15 and not mode==999 and not mode==6 and not mode==24 and not mode==27:
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	else:
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	cmItems = []
	cmItems.append(('Remover dos Favoritos\n%s' % addon_base, 'XBMC.RunPlugin(%s?url=%s&mode=28&name=%s&iconimage=%s)'%(sys.argv[0],urllib.quote_plus(url),urllib.quote_plus(name),urllib.quote_plus(iconimage))))
	liz.addContextMenuItems(cmItems, replaceItems=False)
	liz.setProperty('fanart_image', fanart)
	liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok		
############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None
categoria=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        categoria=urllib.unquote_plus(params["categoria"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)
print "categoria: "+str(categoria)

			
###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
#abrir_url('https://goo.gl/oKyPTl')


if mode==None or url==None or len(url)<1:
        CATEGORIES()
		
		
elif mode==5:
	listar_m3u(url,name)
elif mode==6:
	m3u_Local_Online()
elif mode==15:
	player_addon(name,url,iconimage)
elif mode==16:
	Addon_Settings()
elif mode==24:
	listar_m3u_categorias(name,url,iconimage)
elif mode==25:
	Remover_Source(name)

elif mode==26:
	Adicionar_Favoritos(name,url,iconimage)
	
elif mode==27:
	Listar_Favoritos()
		
elif mode==28:
	Remover_Favoritos(name)
				
elif mode==29:
	MENU_OPCOES()
		
						
elif mode==30:
	Salvar_Listas(url,name)
		
		
		
		
#########################################          FIM
xbmcplugin.endOfDirectory(int(sys.argv[1]))
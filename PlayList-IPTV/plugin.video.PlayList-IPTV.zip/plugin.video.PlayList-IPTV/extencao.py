#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2014
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,io,sys,xbmcvfs,traceback
import json
import extencao
import urlresolver
from BeautifulSoup import BeautifulSoup


addon_base = 'PlayList [COLOR dodgerblue]IPTV[/COLOR]'#Link List Lojink
addon_id = 'plugin.video.PlayList-IPTV'
selfAddon = xbmcaddon.Addon(id=addon_id)
profile = xbmc.translatePath(selfAddon.getAddonInfo('profile').decode('utf-8'))
source_file = os.path.join(profile, 'source_file')
#profile1 = xbmcvfs.mkdir(os.path.join(profile,"Lists"))
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
dialog = xbmcgui.Dialog()    
	
	
def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text = "" if not keyboard.isConfirmed() else keyboard.getText()
	return text

		
def m3u_Local_Online():
	option = dialog.select('Selecione o Modo de Adicionar a Lista M3u',['lista Online','lista Local'])
	if option == 0:
		ADD_LISTA_ONLINE()
	if option == 1:
		ADD_LISTA_LOCAL()	
	elif option:
		sys.exit()		
	
def ADD_LISTA_ONLINE():
	try:
		url = GetKeyboardText(title='link da Lista M3u Online',defaultText='http://')
		if '/' in url or '\\' in url:
			pass
		else:
			dialog.ok(addon_base,'N�o foi possivel adicionar a lista'.decode('unicode_escape'),'')
			sys.exit(0)		
		name = GetKeyboardText('Nome da Lista M3u Online')
		if len(name) > 1:
			source_media = {}
			source_media['name'] = name
			source_media['url'] = url
			source_media['fanart'] = fanart
			if os.path.exists(source_file)==False:
				source_list = []
				source_list.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(source_list))
				b.close()
			else:
				sources = json.loads(open(source_file,"r").read().replace('}][{','},{'))
				sources.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(sources))
				b.close()	
			xbmc.executebuiltin("Container.Refresh")
			sys.exit()
		else:
			dialog.notification(addon_base,'N�o foi possivel adicionar a lista'.decode('unicode_escape'),icones)
			sys.exit(0)
	except: 
		traceback.print_exc()
		sys.exit()
		

def ADD_LISTA_LOCAL():
	try:
		url = dialog.browse(1, '[B]LISTA M3U LOCAL[/B]', 'myprograms', '.txt|.xml|.m3u', False, False, '')
		if '/' in url or '\\' in url:
			pass
		else:
			dialog.ok(addon_base,'N�o Foi Possivel Adicionar a Lista'.decode('unicode_escape'),'')
			sys.exit()		
		name = GetKeyboardText('[B]NOME DA LISTA M3U LOCAL[/B]')
		if len(name) > 1:
			source_media = {}
			source_media['name'] = name
			source_media['url'] = url
			source_media['fanart'] = fanart
			if os.path.exists(source_file)==False:
				source_list = []
				source_list.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(source_list))
				b.close()
			else:
				sources = json.loads(open(source_file,"r").read().replace('}][{','},{'))
				sources.append(source_media)
				b = open(source_file,"w")
				b.write(json.dumps(sources))
				b.close()	
			xbmc.executebuiltin("Container.Refresh")
			sys.exit()
		else:
			dialog.notification(addon_base,'N�o foi possivel adicionar a lista'.decode('unicode_escape'),icones)
			sys.exit(0)	
	except:
		traceback.print_exc()
		sys.exit()
		
		
# -*- coding: UTF-8 -*-

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,time,json,sys

import urlresolver
from BeautifulSoup import BeautifulSoup
import zlib,base64

pluginhandle = int(sys.argv[1])

addon_base = 'Desenhos lojink'
addon_id = 'plugin.video.desenhos lojink'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
#arquivo_add_on = addonfolder + '/FILMES_XMLS.xml'
#arquivo_add_onS = addonfolder + '/FILMES_GOOGLE_DRIVE_XMLS.xml'

import os,sys,xbmcgui,xbmcaddon,xbmc


addon_id			= 'plugin.video.desenhos lojink'
selfAddon			= xbmcaddon.Addon(id=addon_id)
addonfolder			= selfAddon.getAddonInfo('path')	
pesquisar_addon		= addonfolder + '/addon.xml'
itemsss 			= open(pesquisar_addon,'r').read()
F4M					=	xbmc.translatePath('special://home/addons/plugin.video.REPO-LOJINK')


if not os.path.exists(F4M):
	xbmcgui.Dialog().textviewer(addon_base,urllib.unquote('                                                            [COLOR red]ADD-ON BLOQUEADO\n\n\nSE VOC� EST� VENDO ESTA MENSAGEM � PORQU� VOC�  N�O INSTALOU O REPOSIT�RIO DO ADD-ON  QUE ATENDE PELO NOME DE[/COLOR]:  [COLOR green][B]REPO-LOJINK[/B][/COLOR]').decode('unicode_escape'))
	sys.exit(0)	
else:
	pass	


if 'PGFkZG9uIGlkPSJwbHVnaW4udmlkZW8uZGVzZW5ob3MgbG9qaW5rIiBuYW1lPSJEZXNlbmhvcyBsb2ppbmsiIHZlcnNpb249IjAuMC4xIiBwcm92aWRlci1uYW1lPSJsb2ppbmsiPg=='.decode('base64') in itemsss:
	pass
else:
	xbmcgui.Dialog().textviewer(addon_base,urllib.unquote('                                                            [COLOR red]ADD-ON BLOQUEADO\n\n\nSE VOC� EST� VENDO ESTA MENSAGEM � PORQU� ESSE ADD-ON FOI PLAGIADO ENT�O PROCURE O ORIGINAL QUE ATENDE PELO NOME DE[/COLOR]:  [COLOR green][B]'+addon_base+'[/B][/COLOR]\n\n\n[COLOR red]OU PROCURE O REPOSIT�RIO DO ADD-ON[/COLOR]:  [COLOR green][B]REPO LOJINK[/B][/COLOR]').decode('unicode_escape'))
	sys.exit(0)

		
def contar_acessos():
	req = urllib2.Request('https://goo.gl/4P9zxj')
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	
	
############################################################################################################
#                                           MENU ADDON     
############################################################################################################

def CATEGORIES():
	contar_acessos()
	addDir('Desenhos animesonlinetk','-',2,artfolder + 'DESENHOS.png')
	addDir('Desenhos redecanais','http://www.redecanais.info/browse-desenhos-videos-1-title.html',4,artfolder + 'DESENHOS.png')
	i = '''Anima��o'''
	addDir('Filmes Infantis redecanais','http://www.redecanais.info/browse-Animacao-Filmes-videos-1-date.html',4,artfolder + 'DESENHOS.png')
	addDir('Filmes Infantis megaboxfilmesonline','http://megaboxfilmesonline.com/tag/infantil',8,artfolder + 'DESENHOS.png')


###################################################################################
#FUNCOES

from HTMLParser import HTMLParser
h = HTMLParser()		
def items_Beaulti(item,arquivo=False):
	for items in item:
		if not arquivo:
			return items
		else:
			return items.text.encode('utf-8')	
def Listar_Filmes_megaboxfilmesonline(url):
	link = abrir_url(url)
	reg = re.compile('<a href="(.*?)">\s*<img src="(.*?)" alt="(.*?)" height=.*?/>').findall(link)
	for a in reg:
		name = a[2]
		name = name.replace('#8211;','').replace('&','-').replace('Assistir ','').replace('Dublado','(Dublado)').replace(' Gratis','').replace('','').replace('','')
		url = a[0]
		img = a[1]
		addDir(name,url,102,img)
	bsObj = BeautifulSoup(link)		
	nameList = bsObj.findAll('div',attrs={"class": 'wp-pagenavi'})
	pag = len(nameList)
	for items in nameList:#
		pagina_name = items_Beaulti(items.find("span", { "class" : "pages" }))
		pagina_url = items.findAll(attrs={ "class" : "nextpostslink" })[0].get('href')
		addDir('[COLOR green]'+pagina_name.encode('utf-8')+'[/COLOR]',pagina_url.encode('utf-8'),8,'')		
		

def Listar_Desenhos_RedeCanais(url):
	link = abrir_url(url)
	pag = re.compile('<a href="(.*)">&raquo;</a>').findall(link)[0]
	addDir('Ir para Pagina %s'% pag.replace('https://www.redecanais.link/browse-desenhos-videos-','').replace('-title.html','').replace('https://www.redecanais.link/browse-Animacao-Filmes-videos-','').replace('-date.html',''),pag.replace('https','http'),4,artfolder + 'Proxima.png')
	r = '''<a href="(.*?)" class=.*?><span class=.*?><img src="(.*?)" alt="(.*?)" width=.*?>'''
	match = re.compile(r).findall(link)
	for a in match:
		name = a[2]
		url = a[0]
		img = a[1]
		if '-lista-' in url:
			addDir(name,url,6,img)		
		else:
			addDir(name,url,101,img)					
def Listar_Episodios_RedeCanais(url,iconimage):
	base = 'https://www.redecanais.link/'
	uri =  url.replace("https","http")
	link = abrir_url(uri)
	match = re.compile('<strong>(.*?)<.*?strong>(.*?)(<br|<.p)').findall(link)
	for name,urls,tr in match:
		name = '[B][COLOR white]'+h.unescape(name)+'[/COLOR][/B][COLOR white]'+h.unescape(urls.split('- ')[0])+'[/COLOR]'
		name = name.encode('utf-8')
		name = name.replace('</span>','').replace('</strong>','')
		if urls.count('href')==2:
			try:
				urld = re.compile('href="(.*?)"').findall(urls)[0]
				if 'http' in urld:
					pass
				else:
					urld = base+urld
				urle = re.compile('href="(.*?)"').findall(urls)[1]
				if 'http' in urle:
					pass
				else:
					urle = base+urle
			except:
				urld = ''
				urle = ''
			links = urld+'#|#'+urle
			img = iconimage
			addDir(name+'[COLOR dodgerblue]- (Dublado/Legendado)[/COLOR]',links,7,img)	
		else:
			try:
				urld = re.compile('href="(.*?)"').findall(urls)[0]
				if 'http' in urld:
					pass
				else:
					urld = base+urld
			except:
				urld =''
			if 'Legendado' in urls:
				name +='  [COLOR dodgerblue](Legendado)[/COLOR]'
			if 'Dublado' in urls:
				name +='  [COLOR dodgerblue](Dublado)[/COLOR]'
			img = iconimage
			if not '[B][COLOR white]Legendado[/COLOR][/B][COLOR white][/COLOR]' in name:
				addDir(name,urld,101,img)	
def select_link(url):
	urls  = []
	names = []
	uri = url
	setd = uri.split('#|#')
	urls.append(setd[1])
	names.append('(Legendado)')
	urls.append(setd[0])
	names.append('(Dublado)')
	opcao = xbmcgui.Dialog().select(addon_base, names)
	if opcao>= 0:	
		e = urls[opcao]
		Player_RedeCanais(e)
	else:
		exit()
			
def Player_RedeCanais(url):		
	uri = url.replace("https","http")
	link = abrir_url(uri)
	r ='<iframe name="Player".*?src="(.*?)".*?allowFullScreen>\s*</iframe>'
	match = re.compile(r).findall(link)
	for urls in match:
		links = abrir_url(urls)
		matchs = re.compile('file: "(.*?)",').findall(links)[0]
		plays  = matchs+"|Referer="+urls
	listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
	xbmc.Player().play(item=plays, listitem=listItem)			
	sys.exit()	
	
def Listar_Letras():
	list = 'https://www.animesonlinetk.info/150570'
	link = abrir_url(list)
	soup = BeautifulSoup(link)
	match = soup.find('div',{'id':'pluginMestre'})
	for a in match.findAll('a'):
		name = a.text.encode('utf-8')
		url = list
		img = ''
		addDir(name,url,1,img)	
		
def Listar_Episodios(name):
	names = name.lower()
	link = abrir_url('https://www.animesonlinetk.info/150570')
	soup = BeautifulSoup(link)
	match = soup.find('div',{'class':'aba','id':names})
	for a in match.findAll('a'):
		name = a.text.encode('utf-8')
		url = a['href']
		img = ''

		addDir(name,url,3,img)	

def Listar_Epis(url):
	link = abrir_url(url)
	try:
		imags = re.compile("<meta property='og:image' content='(.*)'/>").findall(link)[0]
	except:
		imags = ''
	soup = BeautifulSoup(link,convertEntities=BeautifulSoup.HTML_ENTITIES)#<ul class="lcp_catlist" id="lcp_instance_0">
	match = soup.find('ul',{'class':'lcp_catlist','id':'lcp_instance_0'})
	for a in match.findAll('a'):
		name = a.text.encode('utf-8')
		url = a['href']
		img = imags
		if not 'Todos os Ep' in name:
			addDir(name,url,100,img)	
	
def Links_Megabox(url):
	pass


def Player_megaboxfilmesonline(url):
	link  = abrir_url(url)
	match = re.compile('<iframe src="(.*?)" width=.*?height=.*?allowfullscreen.*?></iframe>').findall(link)[0]
	if 'http://moviestream.video/player.php?id=' in match:
		match = match.replace('player.php?id=','embed.php?url=')
		a = abrir_url(match)
		b = re.compile('{"type": ".*?", "label": ".*?", "file": "(.*?)"}').findall(a)
		url = b[0]
	if 'http://moviestream.video/filmes.php?id=' in match:
		match = match.replace('filmes.php?id=','gd.php?v=')
		a = abrir_url(match)
		b = re.compile('<iframe src="(.*?)".*?frameborder=.*?></iframe>').findall(a)
		url = 'plugin://plugin.video.gdrive?mode=streamURL&url='+b[0].replace('/preview','/edit')	
	url = url
	listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
	xbmc.Player().play(item=url, listitem=listItem)			
	sys.exit()	
							
def Player(url):
	import urlresolver
	link = abrir_url(url)
	url = re.compile('<video src="(.*?)".*?width.*?height.*?>\s*').findall(link)[0]
	listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
	xbmc.Player().play(item=url, listitem=listItem)			
	sys.exit()	
				
def Player_blogger(url):
	listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
	xbmc.Player().play(item=url, listitem=listItem)			
	sys.exit()	
	
		################################################################################################
#                                           FUN�OES FEITAS     #
############################################################################################################		

		
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok

############################################################################################################
#   GET PARAMS     #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None
descripition=None
pagina=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass

try:        
        descripition=urllib.unquote_plus(params["descripition"])
except:
        pass
try:        
        pagina=urllib.unquote_plus(params["pagina"])
except:
        pass




###############################################################################################################
#       MODOS       
###############################################################################################################


if mode==None or url==None or len(url)<1:
        print "aqui inica o addon  asdasdsadahlhlhhhjlljhljhjjklhkljhkhjhkhjhj"
        CATEGORIES()

elif mode==1:
	Listar_Episodios(name)
	
elif mode==2:
	Listar_Letras()
	
elif mode==3:
	Listar_Epis(url)
	
elif mode==4:
	Listar_Desenhos_RedeCanais(url)
	
elif mode==5:
	listar_paginas(url)
	
elif mode==6:
	Listar_Episodios_RedeCanais(url,iconimage)
	
elif mode==7:
	select_link(url)
	
elif mode==8:
	Listar_Filmes_megaboxfilmesonline(url)

		
elif mode==100:
	Player(url)
		
elif mode==101:
	Player_RedeCanais(url)
		
elif mode==103:
	Player_blogger(url)
		
elif mode==102:
	Player_megaboxfilmesonline(url)

	
	
#########################################          FIM
xbmcplugin.endOfDirectory(int(sys.argv[1]))
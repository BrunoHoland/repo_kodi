# -*- coding: utf-8 -*-

import urllib, urllib2, sys, re, os, unicodedata,urlparse
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from BeautifulSoup import BeautifulSoup
from HTMLParser import HTMLParser
h = HTMLParser()		
##############################################################################################
plugin_handle = int(sys.argv[1])
addon_id = 'plugin.video.Desenhos lojink'
mysettings = xbmcaddon.Addon(id = addon_id)
addon_name = 'Desenhos lojink'
profile =xbmc.translatePath(mysettings.getAddonInfo('profile').decode('utf-8'))
home = mysettings.getAddonInfo('path')
fanarts = xbmc.translatePath(os.path.join(home, 'fanart2.jpg'))
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
dialog = xbmcgui.Dialog()    
Proxima = xbmc.translatePath(os.path.join(home, 'Proxima.png'))
#############################################################################################
from bs4 import BeautifulSoup as bs4

def Soups(url):
	link = abrir_url(url)
	return bs4(link)			
	
def log(log):
	xbmc.log('%s'% log, xbmc.LOGNOTICE)
		
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def GetEncodeString(str):
	try:
		str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
	except:
		try:
			str = str.encode("utf-8")
		except:
			pass
	return str

def add_dir(name, url, mode, iconimage, fanart,description):
	if 'Menus' in description:
		try: 
			name = GetEncodeString(name)
		except: pass
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)	
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok

def add_link(name, url, mode, iconimage, fanart,description):
	u = sys.argv[0]+ "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true')
	contextMenu = []

	liz.addContextMenuItems(contextMenu)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  		

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	
params = get_params()
#log(params)
url = None
name = None
mode = None
iconimage = None
description  = None
try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass

try: iconimage = urllib.unquote_plus(params["iconimage"])
except: pass  

try: description = urllib.unquote_plus(params["description"])
except: pass  


Repo = xbmc.translatePath('special://home/addons/plugin.video.REPO-LOJINK')
if os.path.exists(Repo)==False:
	dialog.textviewer(addon_name,'                                                            ADD-ON BLOQUEADO\n\n\nSE VOCÊ ESTÁ VENDO ESTÁ MENSAGEM É PORQUÊ VOCÊ  NÃO INSTALOU O REPOSITÓRIO DO ADD-ON.\nNOME DO REPOSITÓRIO OFICIAL:   [COLOR red]REPO-LOJINK[/COLOR]\nFAÇA DOWNLOAD PELO LINK:         [COLOR red]bit.ly/Repo_Lojink_2[/COLOR]'.decode('unicode_escape'))
	sys.exit()	
	
dominio = '.cz/'	
base = 'https://www.redecanais'+dominio+''
if mode==None:
	add_dir('Desenhos animesonlinebr', 'https://www.animesonlinebr.com.br/desenhos.html', 1, icon, fanart,'Menu')
	add_dir('Desenhos redecanais', 'https://www.redecanais.cz/browse-desenhos-videos-1-title.html', 5, icon, fanart,'Menu')
	add_dir('Filmes redecanais', 'http://www.redecanais.cz/browse-Animacao-Filmes-videos-1-date.html', 5, icon, fanart,'Menu')

elif mode==1:#animesonlinebr
	link = abrir_url(url)
	soup  = bs4(link)
	rew = soup.find('div',{'id':"abasSingle"})
	for a in rew.findAll('a'):
		name = a.text.encode('utf-8')
		urls = url+a['href']
		add_dir(name, urls, 2, icon, fanart,'')		
		
		
elif mode==2:#animesonlinebr
	names = name.lower()
	link = abrir_url(url)
	soup  = bs4(link)
	rew = soup.find('div',{'id':names,'class':"aba"})#('div',{'id':"abasSingle"})
	for a in rew.findAll('a'):
		name = a.text.encode('utf-8')
		urls = a['href']
		add_dir(name, urls, 3, icon, fanart,'')				


elif mode==3:#animesonlinebr
	link = abrir_url(url)
	soup  = bs4(link)
	try:
		img = soup.find('meta',{'property':'og:image'})['content']
	except:
		img = icon
	match = soup.find('ul',{'class':'lcp_catlist','id':'lcp_instance_0'})
	for a in match.findAll('a'):
		name = a.text.encode('utf-8')
		urls = a['href']
		add_link(name, urls, 4, img, fanart,'')	

elif mode==4:#animesonlinebr
	soup  = Soups(url)
	repro = soup.find('link',{'itemprop':'embedURL'})['href']
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type='Video', infoLabels={'Title':name})
	liz.setProperty("IsPlayable", "true")
	liz.setPath(repro)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

elif mode==5:
	link = abrir_url(url)
	soup = BeautifulSoup(link)
	try:
		proxima_pagina_url = re.compile('<li class="">\s*<a href="(.*?)">&raquo;</a>').findall(link)[0].replace('./',base)
		add_dir('[COLOR blue]Próxima Página[/COLOR]',proxima_pagina_url,5,Proxima, fanarts,'Menus')
	except: pass
	r = '''<a href="(.*?)" class=.*?><span class=.*?><img src="(.*?)" alt="(.*?)" width=.*?>'''
	match = re.compile(r).findall(link)
	for a in match:
		try:
			name = a[2].replace('&amp;','&')#h.unescape(a[2])
		except: name = name
		url = a[0].replace('./',base)
		img = a[1]
		if '-lista-de-' in url or '-de-episodios' in url or '-lista-completa' in url:
			mode = 6
			add_dir(name,url,mode,img, fanarts,'')
		else:	
			mode = 7
			add_link(name,url,mode,img, fanarts,'')	
		
			
elif mode==6:
	link = abrir_url(url)
	for a in re.compile('<strong>(.*?)(<a.*?)(<.p|<br)').findall(link):
		try: name = h.unescape(a[0]).replace('</strong>','').replace('</span><br /> <strong>','\n').encode('utf-8')
		except: name = name.replace('</strong>','').replace('</span><br /> <strong>','\n')
		name = (name+'asistir').replace(' - asistir','').replace('</strong>','').replace('<strong>','').replace('<span style="font-size: x-large;">','')
		name = name.replace('</span> <br />','\n')
		name = name.replace('- asistir','')
		try: name = name.split('<span')[0]
		except: pass
		urls = re.compile(' href=[",\'](.*?)[",\']').findall(a[1])
		if len(urls)==2:
			if not 'http' in urls[0]:
				link1 = base+urls[0]
			else:
				link1 = urls[0]
			if not 'http'  in urls[1]:
				link2 = base+urls[1]
			else:
				link2 = urls[1]
			select  = '%s<|>%s' % (link1,link2)
			if '\n' in name:
				if not name=='asistir':
					add_link(name.split('\n')[0],'SimSnao',10000,iconimage, fanarts,'')
					add_link(name.split('\n')[1],select,8,iconimage, fanarts,'')
			else:
				if not name=='asistir':
					add_link(name,select,8,iconimage, fanarts,'')
		else:
			if not 'http' in urls[0]:
				linksd = base+urls[0]
			else:
				linksd = urls[0]
			if '\n' in name:
				if not name=='asistir':
					add_link(name.split('\n')[0],'SimSnao',10000,iconimage, fanarts,'')
					add_link(name.split('\n')[1],linksd,7,iconimage, fanarts,'')
			else:
				if not name=='asistir':
					add_link(name,linksd,7,iconimage, fanarts,'')		
		
elif mode==7:
	link = abrir_url(url)
	embed = re.compile('<iframe name="Player" ="" src="(.*?)" frameborder="0" height="400" scrolling="no" width="640" allowFullScreen>').findall(link)[0]
	player = abrir_url(embed)
	player = player.split(' link: "')[-1].split('"')[0]#re.compile('link: "(.*?.mp4)",\s*hide: "true",').findall(player)[0]
	repro = player+'|Referer='+embed
	
	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type='Video', infoLabels={'Title':name})
	liz.setProperty("IsPlayable", "true")
	liz.setPath(repro)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)					
										
elif mode==8:
	links = url.split('<|>')
	names = []
	urls  = []
	names.append('Dublado')
	urls.append(links[0])
	names.append('Legendado')
	urls.append(links[1])
	opcao = xbmcgui.Dialog().select(addon_name, names)
	if opcao>= 0:
		repro = urls[opcao]	
		link = abrir_url(repro)
		embed = re.compile('<iframe name="Player" ="" src="(.*?)" frameborder="0" height="400" scrolling="no" width="640" allowFullScreen>').findall(link)[0]
		player = abrir_url(embed)
		player = player.split(' link: "')[-1].split('"')[0]#re.compile('link: "(.*?)",\s*hide: "true",').findall(player)[0]
		repro = player+'|Referer='+embed
		
		liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setInfo(type='Video', infoLabels={'Title':name})
		liz.setProperty("IsPlayable", "true")
		liz.setPath(repro)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	else:
		sys.exit()
		
		
		
		
		
		
		
		
		
		
xbmcplugin.endOfDirectory(plugin_handle)
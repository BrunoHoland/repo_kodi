# -*- coding: UTF-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os
import sys
from BeautifulSoup import BeautifulSoup


addon_base = '[COLOR lawngreen]Play Torrents[/COLOR]'
addon_id = 'plugin.video.playtorrents'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
base = 'http://www.megatorrentshd.com'
dialog = xbmcgui.Dialog()    
def CATEGORIES():
	addDir('[COLOR whitesmoke]CATEGORIAS[/COLOR]','http://www.megatorrentshd.com/',4,artfolder + 'Categorias.png')
	addDir('[COLOR whitesmoke]DESTAQUES[/COLOR]','http://www.megatorrentshd.com/destaque/',2,artfolder + 'Destaques.png')
	addDir('[COLOR whitesmoke]LANÇAMENTOS[/COLOR]','http://www.megatorrentshd.com/category/lancamentos',2,artfolder + 'lancamentos.png')
	addDir('[COLOR whitesmoke]SÉRIES[/COLOR]','http://www.megatorrentshd.com/series/',2,artfolder + 'series.png')
	addDir('[COLOR whitesmoke]PESQUISA[/COLOR]','-',5,artfolder + 'PESQUISA.png')	
	
	
def categorias(url):
	link = abrir_url(url)
	soup = BeautifulSoup(link,convertEntities=BeautifulSoup.HTML_ENTITIES)
	match = soup.find('ul',{'class':"sub-menu"}).findAll('li')
	for a in match:
		name = a.text.encode('utf-8')
		url = a.a['href']
		if url.startswith('http'):
			url = url
		else:
			url = base+url
		addDir(name,url,2,icones)
		
		
		
def items_Beaulti(item,arquivo=False):
	for items in item:
		if not arquivo:
			return items
		else:
			return items.text.encode('utf-8')	

			
def listar_filmes(url):#title
	link  = abrir_url(url)
	html = link
	bsObj = BeautifulSoup(html)
	nameList = bsObj.findAll('div',attrs={"class": 'ItemN'})
	for items in nameList:#
		idiomas = items.findAll('span',attrs={'class':'idi'})[0]
		idioma = idiomas.text.encode('utf-8')		
		qualitys = items_Beaulti(items.findAll('span',attrs={'class':'quality'}),True)
		quality = qualitys
		filmes = items.findAll("div", {"class":"peli"})[0]
		name = filmes.img['alt'].encode('utf-8')
		img = filmes.img['src']
		url = filmes.a['href']
		name = name.split('– HD')[0].split(') HD')[0].split(' – BluRay')[0].split(' – WEB-DL')[0]
		name = name.replace('   ',' ').replace(' Completa ',' ').replace('   ',' ').replace('   ',' ')
		addDir('%s - %s - %s' % (name,idioma,quality),url.encode('utf-8'),99,img.encode('utf-8'))
		
	nameList = bsObj.findAll('div',attrs={"class": 'wp-pagenavi'})
	for items in nameList:#
		pagina_name = items_Beaulti(items.find("span", { "class" : "pages" }))
		pagina_url = items.findAll(attrs={ "class" : "nextpostslink" })[0].get('href')
		addDir('[COLOR green]'+pagina_name.encode('utf-8')+'[/COLOR]',pagina_url.encode('utf-8'),2,artfolder + 'Proxima.png',True)


def pesquisa():
	keyb = xbmc.Keyboard('', 'Encontre filmes, atores e diretores')
	keyb.doModal()
	if (keyb.isConfirmed()):
		search = keyb.getText()
		parametro_pesquisa=urllib.quote(search)
		url = 'http://www.megatorrentshd.com/?s='+parametro_pesquisa
		listar_filmes(url)
	else:
		sys.exit()
	
	
def Listar_epiEfil(url,name,iconimage):
	link  = abrir_url(url)
	temporada = url
	addDir('[COLOR lawngreen]Sinopse:%s[/COLOR]'%name.split('(')[0],url,20,iconimage,False)
	bsObj = BeautifulSoup(link)
	nameList = bsObj.findAll(attrs={"class":"trailer litebox"})
	for filmes in nameList:#
		Trailer =  filmes.get('href')	
		addDir('[COLOR lawngreen]Play Trailer[/COLOR]',Trailer,999,iconimage)
	match = bsObj.find('div',{'id':'categoria','class':'box_item center-widget'})
	for a in match.findAll('div'):#('a'):
		name = a.text.encode('utf-8')
		try:
			url = a.a['href'].encode('utf-8')
		except:
			url= 'True'
		if name=='':
			nomi = url.split('&dn=')[-1].split('&tr=')[0]
			name = urllib.unquote_plus(urllib.unquote_plus(nomi.split('[')[-0]))
		addDir(name,url,98,iconimage,True)
	
def Play_Trailer(url,name,iconimage):
	link  = abrir_url(url)
	bsObj = BeautifulSoup(link)
	nameList = bsObj.findAll(attrs={"class":"trailer litebox"})
	for filmes in nameList:#
		Trailer =  filmes.get('href')	
		xbmc.log("%s" % Trailer)
		#addDir('[COLOR green]Play Trailer[/COLOR]',Trailer,999,iconimage)
		Trailers(Trailer,name,iconimage)
def Descricao(url):
	html  = abrir_url(url)
	bsObj = BeautifulSoup(html,convertEntities=BeautifulSoup.HTML_ENTITIES)
	#nameList = bsObj.findAll("a", {"class":"trailer litebox"})
	nameList = bsObj.findAll(attrs={"class": 'meta_datos'})
	for filmes in nameList:#
		print(filmes)#
		names = filmes.h1.text
		imdb = filmes.find('div',{'class':'views'})
		imdbs = imdb.text.encode('utf-8').replace('|',' | ')
		description = bsObj.find(attrs={"class": 'meta_datos'}).findAll('p')
		descriptions = description[1].text.split('|')[-1]
		showText(addon_base,'Sinopse: %s'% names+'\n\n'+imdbs+'\n\n'+descriptions)

		
def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            return 
        except:
            pass	

				
def Player_torrent(url,name,iconimage):
	if 'magnet:?xt' in url:	#'xt=urn:btih:([^&/]+) plugin://plugin.video.elementum/play?uri=%s
		if selfAddon.getSetting('player_torrent') == "Quasar":
			url = 'plugin://plugin.video.quasar/play?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Pulsar":
			url = 'plugin://plugin.video.pulsar/play?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Yatp":
			url = 'plugin://plugin.video.yatp/?action=play&torrent={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Torrenter":
			url = 'plugin://plugin.video.torrenter/?action=playSTRM&url={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "XbmcTorrent":
			url = 'plugin://plugin.video.xbmctorrent/play/{0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Torrentin":
			url = 'plugin://plugin.video.torrentin/?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Elementum":
			url = 'plugin://plugin.video.elementum/play?uri={0}'.format(urllib.quote_plus(url))
		elif selfAddon.getSetting('player_torrent') == "Ace Stream (apk)":
			if xbmc.getCondVisibility('system.platform.android'):
				xbmc.executebuiltin('XBMC.StartAndroidActivity("org.acestream.media","android.intent.action.VIEW","","'+url+'")')
			else:
				dialog.ok(addon_base,  "FUNCIONA APENAS EM SISTEMAS ANDROID !!!".decode('unicode_escape'),'')
				sys.exit(0)	
		elif selfAddon.getSetting('player_torrent') == "BitX Torrent Video Player":
			if xbmc.getCondVisibility('system.platform.android'):
				xbmc.executebuiltin('XBMC.StartAndroidActivity("tv.bitx.media","android.intent.action.VIEW","","'+url+'")')
			else:
				dialog.ok(addon_base,  "FUNCIONA APENAS EM SISTEMAS ANDROID !!!".decode('unicode_escape'),'')
				sys.exit(0)	
				
				
	listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
	xbmc.Player().play(item=url, listitem=listItem)			
	sys.exit()	
	
def Trailers(url,name,iconimage):
	try:
		link = Lojink_resolver_youtube(url)
		listItem = xbmcgui.ListItem(name, thumbnailImage=iconimage)
		xbmc.Player().play(item=link, listitem=listItem)			
		sys.exit()	
	except TypeError:
		dialog.ok(addon_base,'Desculpe, não foi possivel reproduzir o video.','','')
def Lojink_resolver_youtube(url):
	import yt
	items =  url#res[1]
	item = yt.Scrape(items)
	return item 
############################################################################################################
#                                           FUNÇOES FEITAS                                                 #
############################################################################################################		
def setViewMenu() :		
	opcao = selfAddon.getSetting('menuVisu')
	
	if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
	elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
	elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		
def setViewFilmes() :
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')

		opcao = selfAddon.getSetting('filmesVisu')

		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		elif opcao == '3': xbmc.executebuiltin("Container.SetViewMode(501)")
		elif opcao == '4': xbmc.executebuiltin("Container.SetViewMode(508)")
		elif opcao == '5': xbmc.executebuiltin("Container.SetViewMode(504)")
		elif opcao == '6': xbmc.executebuiltin("Container.SetViewMode(503)")
		elif opcao == '7': xbmc.executebuiltin("Container.SetViewMode(515)")
		
		
def abrir_url(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except IOError:#     except urllib2.HTTPError, e:
		dialog.notification(addon_base,'Não foi possivel acessar o servidor.',icones)
		sys.exit(0)

def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	cmItems = []
	if mode==99:
		cmItems.append(('[COLOR lawngreen]Ver Sinopse[/COLOR]', 'XBMC.RunPlugin(%s?url=%s&mode=20&name=%s&iconimage=%s)'%(sys.argv[0], url,name,iconimage)))	
		cmItems.append(('[COLOR lawngreen]Play Trailer[/COLOR]', 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s&iconimage=%s)'%(sys.argv[0], url,name,iconimage)))	
	liz.addContextMenuItems(cmItems, replaceItems=False)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok
	
def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)



###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
#abrir_url('https://goo.gl/oKyPTl')


if mode==None or url==None or len(url)<1:
        print "aqui inica o addon  asdasdsadahlhlhhhjlljhljhjjklhkljhkhjhkhjhj"
        CATEGORIES()
      #  teste = abrir_url('https://goo.gl/oKyPTl')	


		
	  
elif mode==2: listar_filmes(url)
elif mode==6: listar_pesquisa(url)
elif mode==3: listar_series(url)
elif mode==4: categorias(url)
elif mode==5: pesquisa()

elif mode==20: Descricao(url)
elif mode==21: Play_Trailer(url,name,iconimage)
elif mode==99: Listar_epiEfil(url,name,iconimage)
elif mode==98: Player_torrent(url,name,iconimage)
elif mode==999: Trailers(url,name,iconimage)

#########################################          FIM
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2014
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################

import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,os

import urlresolver
from BeautifulSoup import BeautifulSoup



pluginhandle = int(sys.argv[1])

versao = '0.0.1'
addon_base = 'tokusatsuBr'
addon_id = 'plugin.video.tokusatsuBr'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'#
fanart = addonfolder + '/fanart.jpg'
icones = addonfolder + '/icon.png'
#logos = addonfolder + 'epg.txt'
logos = xbmc.translatePath(os.path.join(addonfolder,'epg.txt'))

		
def contar_acessos():
	req = urllib2.Request('https://goo.gl/sb9b22')
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
	
############################################################################################################
#                                           MENU ADDON                                                 
############################################################################################################

def CATEGORIES():
	#contar_acessos()
	#tempU()
	#addDir('[COLOR whitesmoke]CATEGORIAS[/COLOR]','https://animeqcartoon.blogspot.com.br/p/lista-de-cartoons.html',3,artfolder + 'Dublados.png')
	#addDir('[COLOR whitesmoke]A a Z[/COLOR]','https://animeqcartoon.blogspot.com.br/p/lista-de-cartoons.html',5,artfolder + 'Dublados.png')
	addDir('[COLOR whitesmoke]FILMES[/COLOR]','http://www.animesonlinebr.com.br/tokusatsus.html',1,artfolder + 'lanca.png')
	
	setViewMenu()	
	
def open_file(file):
    content = open(file, 'r')
    link = content.read()
    content.close()
    return link	
###################################################################################
#FUNCOES


def listar_sucesos():#title
	link = abrir_url('http://www.animesonlinebr.com.br/tokusatsus.html')
	reg = re.compile('<a title=".*?" href="(.*?)">(.*?)</a>').findall(link)
	for url,name in reg:
		addDir('[B]'+name+'[/B]',url,2,icones)	
		
	setViewFilmes() 

############################################################################################################
#                                           OPEN SETINGS                                                
############################################################################################################

def pegar_imagem(url):
	link = abrir_url(url)
	item1 = re.compile('<meta property="og:image" content="(.*?)" />').findall(link)
	for items in item1:
		item = items 
		return item
		
def pegar_url(url):
	link = abrir_url(url)
	item1 = re.compile('<link itemprop="embedURL" href="(.*?)">').findall(str(link))
	for items in item1:
		item = items 
		return item
	
	
def pegar_link(url):
	item = []
	#item1 = []
	link = abrir_url(url)
	imagen = pegar_imagem(url)
	match = re.compile('<li>\s*<a href="(.*?)" title=".*?">(.*?)</a>').findall(link)
	for url,name in match:
		item.append(url)
		p = len(item)
		nop = p+0
		p = 1
		#if '-' in name:
		name = name.split('-')[-1]
		addDir('[B]'+name+'[/B]',url,3,str(imagen),False)
		
	setViewFilmes() 
		
			
def pegar_link11(url,name):
	html = abrir_url(url)
	names  = ['[COLOR white][B]Player 1[/B][/COLOR]','[COLOR white][B]Player 2[/B][/COLOR]','[COLOR white][B]Player 3[/B][/COLOR]']
	link = re.compile('<link itemprop="embedURL" href="(.*?)">').findall(html)[0]
	opcao = xbmcgui.Dialog().select('[COLOR white][B]SELECIONE O PLAYER PARA O: [/B][/COLOR]' + name, names)
	if opcao>= 0:
		name = names[opcao]
		playlist = xbmc.PlayList(1)
		playlist.clear()
		try:
			listitem = xbmcgui.ListItem(name,thumbnailImage=iconimage)
			listitem.setInfo("Video", {"Title":name})
			listitem.setProperty('mimetype', 'video/mp4')    
			playlist.add(link,listitem)
			xbmcPlayer = xbmc.Player()
			xbmcPlayer.play(playlist)
		except:
			pass	
	
	
def pegar_link122(url):
	print url
	import urlresolver
	url1 = urlresolver.resolve(url)
	if url1:
		try:
			pl=xbmc.PlayList(1)
			pl.clear()
			listitem = xbmcgui.ListItem(path=url1, thumbnailImage=iconimage)
			xbmc.PlayList(1).add(url1, listitem)
			xbmc.Player().play(pl)
			sys.exit(0)
		except:
			sys.exit(0)
	else:
		pl=xbmc.PlayList(1)
		pl.clear()
		listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
		xbmc.PlayList(1).add(url, listitem)
		xbmc.Player().play(pl)
		sys.exit(0)
	
		################################################################################################
#                                           FUNÇOES FEITAS                                                 #
############################################################################################################		
def setViewMenu() :
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		
		opcao = selfAddon.getSetting('menuVisu')
		
		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		
def setViewFilmes() :
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')

		opcao = selfAddon.getSetting('filmesVisu')

		if   opcao == '0': xbmc.executebuiltin("Container.SetViewMode(50)")
		elif opcao == '1': xbmc.executebuiltin("Container.SetViewMode(51)")
		elif opcao == '2': xbmc.executebuiltin("Container.SetViewMode(500)")
		elif opcao == '3': xbmc.executebuiltin("Container.SetViewMode(501)")
		elif opcao == '4': xbmc.executebuiltin("Container.SetViewMode(508)")
		elif opcao == '5': xbmc.executebuiltin("Container.SetViewMode(504)")
		elif opcao == '6': xbmc.executebuiltin("Container.SetViewMode(503)")
		elif opcao == '7': xbmc.executebuiltin("Container.SetViewMode(515)")
		
		
def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link



def addDir(name,url,mode,iconimage,pasta=True,total=1,plot=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo( type="video", infoLabels={ "title": name, "plot": plot } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
	return ok

############################################################################################################
#                                               GET PARAMS                                                 #
############################################################################################################
              
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

      
params=get_params()
url=None
name=None
mode=None
iconimage=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

try:        
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Iconimage: "+str(iconimage)



###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
#abrir_url('https://goo.gl/oKyPTl')


if mode==None or url==None or len(url)<1:
        print "aqui inica o addon  asdasdsadahlhlhhhjlljhljhjjklhkljhkhjhkhjhj"
        listar_sucesos()
    #    teste = abrir_url('https://goo.gl/oKyPTl')	
		

###########################         listar videos

elif mode==1: listar_sucesos()

elif mode==2: pegar_link(url)
elif mode==3: pegar_link11(url,name)

#########################################          FIM
xbmcplugin.endOfDirectory(int(sys.argv[1]))
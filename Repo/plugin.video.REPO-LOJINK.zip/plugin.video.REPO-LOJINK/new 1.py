import base64
import zlib
bruno='''
def CATEGORIES():#decode_base64_and_inflate(linkes)
    link = OPEN_URL(decode_base64_and_inflate(linkes)).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
'''

print base64.b64encode(b''bruno)
#   script.ezmaintenance
#   Copyright (C) 2016  SchisM
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.


import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import extract
import time
import zipfile
import downloader
import plugintools
import ntpath
import time
import default

addon_id = 'plugin.program.ADD-ONS REPOSITORY'
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dialog = xbmcgui.Dialog()    
DIALOG = xbmcgui.Dialog()
# if setting('autoclean') == 'true':
	# control.clearCache()
versao1 = default.versao="(.+?)"

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

	
def atalizacao():
    versa = urllib2.Request('http://brunoholanda.pe.hu/versaoaddons.txt')# A VERSAO DO ADD-ON COM INFORMACAO E ARQUIVO ZIP
    link = urllib2.urlopen(versa).read()
    match = re.compile('versao="(.+?)"\s*instaler="(.+?)"\s*informa="(.+?)"').findall(link)
    for ver,instaler,informa in match:
			if versao1 != ver:    
			   xbmc.log('<###################################NOVA VERSAO '+versao1+'###################################################################################')
			   mais(instaler,informa)
			
			
			
def mais(url,informa):
    choice = xbmcgui.Dialog().yesno('[COLOR white][B]ADD-ON[/B][/COLOR]',''+informa,yeslabel='[COLOR=green]SIM[/COLOR]',nolabel='[COLOR=red]NAO[/COLOR]')
    if choice == 0:
        return
    elif choice == 1:
        pass
    path = xbmc.translatePath(os.path.join('special://home/addons/packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("AGUARDE POR FAVOR","ATUALIZANDO O ADD-ON ",'', 'TERMINANDO')
    lib=os.path.join(path, versao1+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://home/addons'))
    time.sleep(2)
    dp.update(0,"", "INSTALANDO POR FAVOR ESPERE")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    UpdateMe_local_atualiza()	
	   
def UpdateMe_local_atualiza():
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")      
        dialog=xbmcgui.Dialog(); dialog.ok("ADD-ON ATUAIZADO",  "",icon)  

atalizacao()
		
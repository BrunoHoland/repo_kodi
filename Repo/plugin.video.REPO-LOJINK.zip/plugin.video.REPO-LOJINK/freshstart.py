import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import common as Common
import shutil

AddonTitle="Bandicoot Wizard"
HOME         =  xbmc.translatePath('special://home/')
EXCLUDES     = ['plugin.program.bandicootwizard']
dp = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

def fresh():

	choice2 = xbmcgui.Dialog().yesno("[COLOR=orange]FRESH START?[/COLOR]", 'Are you absolutely certain you want to wipe this install?', '', 'All addons & settings EXCLUDING THIS WIZARD will be completely wiped!', yeslabel='[COLOR=green]Yes[/COLOR]',nolabel='[COLOR=red]No[/COLOR]')
	if choice2 == 0:
		return
	elif choice2 == 1:
		dp.create(AddonTitle,"Wiping Install",'Wiping Now.............', 'Please Wait')
		try:
			for root, dirs, files in os.walk(HOME,topdown=True):
				dirs[:] = [d for d in dirs if d not in EXCLUDES]
				for name in files:
					try:
						os.remove(os.path.join(root,name))
						os.rmdir(os.path.join(root,name))
					except: pass
                        
				for name in dirs:
					try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
					except: pass
		except: pass
	
	dp.create(AddonTitle,"Wiping Install",'Removing empty folders.', 'Please Wait')
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	Common.REMOVE_EMPTY_FOLDERS()
	
	dialog.ok(AddonTitle,'Wipe Successful, please restart Kodi/SPMC for changes to take effect.','','')
	Common.killxbmc()
